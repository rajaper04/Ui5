sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	'./Formatter'
], function(Controller, MessageBox, Formatter, Filter, oDataSelected, oLoc, oHsp, oPack, oState, oCity, oPincode, oHospital,
	othrDocCommentsIP, othrDocCommentsMS, othrDocCommentsIS, othrDocCommentsMP) {
	"use strict";

	return Controller.extend("ZHR_ANPROP_APPR.controller.FirstView", {

		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._onRead(this);
		},

		onRequestClick: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
			this._onRead(this);

		},

		onListItemPress: function(oEvent) {
			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("oModelReq");
			var sPath = oContext.getPath();
			var oModel = oContext.getModel();
			oDataSelected = oModel.getProperty(sPath);
			if (oDataSelected) {

				//Movable Purchase;

				var selTab = this.getView().byId("idIconTabBarNoIcons");
				selTab.setSelectedKey(oDataSelected.TabInd);

				//this.getView().byId("pro").setValue(oDataSelected.PropertyDescriMp);
				//this.getView().byId("make").setValue(oDataSelected.MakeModelMp);

				othrDocCommentsIP = oDataSelected.DocTypeIP;
				othrDocCommentsIS = oDataSelected.DocTypeIS;
				othrDocCommentsMP = oDataSelected.DocTypeMP;
				othrDocCommentsMS = oDataSelected.DocTypeMS;

				this.getView().byId("empname333").setValue(oDataSelected.Zindicator);
				this.getView().byId("pro").setValue(oDataSelected.PropertyDescriMp);
				this.getView().byId("make").setValue(oDataSelected.MakeModelMp);
				this.getView().byId("DP4").setValue(oDataSelected.TentativeDateMp);
				this.getView().byId("ref").setValue(oDataSelected.RefNumDateMp);
				this.getView().byId("party").setValue(oDataSelected.PartyNameAddMp);
				this.getView().byId("relation").setValue(oDataSelected.RelPartyEmpMp);
				this.getView().byId("detailsan_MP").setValue(oDataSelected.DetailsDealerMp);
				this.getView().byId("declare").setValue(oDataSelected.AnyOtherFactsMp);

				if (oDataSelected.PageIndicator === "Priorview") {
					this.getView().byId("MP_Property_AprRemarks").setValue(oDataSelected.ZPAGE1TEXT1);
					//	this.getView().byId("MP_SRC_AprRemarks").setValue(oDataSelected.ZPAGE1TEXT2);
				}
				if (oDataSelected.PageIndicator === "Postview") {
					this.getView().byId("MP_Property_AprRemarks").setValue(oDataSelected.ZPOST1TEXT1);
					//	this.getView().byId("MP_SRC_AprRemarks").setValue(oDataSelected.ZPOST1TEXT2);
				}
				if (oDataSelected.PageIndicator === "Preapprove") {
					this.getView().byId("MP_Property_AprRemarks").setValue(oDataSelected.ZPRE1TEXT1);
					//	this.getView().byId("MP_SRC_AprRemarks").setValue(oDataSelected.ZPRE1TEXT2);
				}

				//	Movable Sales set;
				this.getView().byId("des").setValue(oDataSelected.PropertyDescriMs);
				this.getView().byId("makem").setValue(oDataSelected.MakeModelMs);
				this.getView().byId("DP5").setValue(oDataSelected.TentativeDateMs);
				this.getView().byId("refer").setValue(oDataSelected.RefNumDateMs);
				this.getView().byId("partyn").setValue(oDataSelected.PartyNameAddMs);
				this.getView().byId("relations").setValue(oDataSelected.RelPartyEmpMs);
				this.getView().byId("det").setValue(oDataSelected.DetailsDealerMs);
				this.getView().byId("dec").setValue(oDataSelected.AnyOtherFactsMs);
				if (oDataSelected.PageIndicator === "Priorview") {
					this.getView().byId("MS_Property_AprRemarks").setValue(oDataSelected.ZPAGE2TEXT1);
					// this.getView().byId("MS_SRC_AprRemarks").setValue(oDataSelected.ZPAGE2TEXT2);
				}
				if (oDataSelected.PageIndicator === "Postview") {
					this.getView().byId("MS_Property_AprRemarks").setValue(oDataSelected.ZPOST2TEXT1);
					// this.getView().byId("MS_SRC_AprRemarks").setValue(oDataSelected.ZPOST2TEXT2);
				}
				if (oDataSelected.PageIndicator === "Preapprove") {
					this.getView().byId("MS_Property_AprRemarks").setValue(oDataSelected.ZPRE2TEXT1);
					// this.getView().byId("MS_SRC_AprRemarks").setValue(oDataSelected.ZPRE2TEXT2);
				}

				//	Immovable purchase set;		
				this.getView().byId("proper").setValue(oDataSelected.PropertyDescriIp);
				this.getView().byId("DOYPsale").setValue(oDataSelected.TentativeDateIp);
				this.getView().byId("Coymp").setValue(oDataSelected.CompleteAddrIp);
				this.getView().byId("EYMO").setValue(oDataSelected.OwnershipPerIp);

				this.getView().byId("IP_Property_AprRemarks").setValue(oDataSelected.TentativePurIp);

				this.getView().byId("CogmpSt_post").setValue(oDataSelected.StateIP);
				this.getView().byId("CogmpDis_post").setValue(oDataSelected.DistrictIP);
				this.getView().byId("CogmpPin_post").setValue(oDataSelected.PinIP);

				this.getView().byId("EYMODep_post").setValue(oDataSelected.OwnershipDepndtIp);
				this.getView().byId("EYMOOth_post").setValue(oDataSelected.OwnershipotherIp);

				this.getView().byId("matd").setValue(oDataSelected.MoaPsgmlIp);
				this.getView().byId("refern").setValue(oDataSelected.RefNumDateIp);
				this.getView().byId("partyad").setValue(oDataSelected.PartyNameAddIp);
				this.getView().byId("Pne").setValue(oDataSelected.RelPartyEmpIp);
				this.getView().byId("detailsd").setValue(oDataSelected.DetailsDealerIp);
				this.getView().byId("declareemp").setValue(oDataSelected.AnyOtherFactsIp);

				// if (oDataSelected.PageIndicator === "Priorview") {
				// 	this.getView().byId("IP_Property_AprRemarks").setValue(oDataSelected.ZPAGE3TEXT1);
				// 	// this.getView().byId("Ip_SRC_AprRemarks").setValue(oDataSelected.ZPAGE3TEXT2);
				// }
				// if (oDataSelected.PageIndicator === "Postview") {
				// 	this.getView().byId("IP_Property_AprRemarks").setValue(oDataSelected.ZPOST3TEXT1);
				// 	// this.getView().byId("Ip_SRC_AprRemarks").setValue(oDataSelected.ZPOST3TEXT2);
				// }
				// if (oDataSelected.PageIndicator === "Preapprove") {
				// 	this.getView().byId("IP_Property_AprRemarks").setValue(oDataSelected.ZPRE3TEXT1);
				// 	// this.getView().byId("Ip_SRC_AprRemarks").setValue(oDataSelected.ZPRE3TEXT2);
				// }

				//	Immovable sales set;	
				this.getView().byId("desproIPS").setValue(oDataSelected.PropertyDescriIs);
				this.getView().byId("DOGPsale").setValue(oDataSelected.TentativeDateIs);
				this.getView().byId("Cogmp").setValue(oDataSelected.CompleteAddrIs);

				this.getView().byId("Comp_IState_post").setValue(oDataSelected.StateIS);
				this.getView().byId("Comp_ISDis_post").setValue(oDataSelected.DistrictIS);
				this.getView().byId("Comp_ISPin_post").setValue(oDataSelected.PinIS);

				this.getView().byId("EMMODep_post").setValue(oDataSelected.OwnershipDepndtIs);
				this.getView().byId("EMMOOth_post").setValue(oDataSelected.OwnershipOtherIs);
				this.getView().byId("propertgypr").setValue(oDataSelected.TentativePurIs);

				if (oDataSelected.LeasedorfreeholdIP === "Leased") {
					this.getView().byId("LeasedGrpA").setSelected(true);
					this.getView().byId("FreeholdGrpA").setSelected(false);
				} else {
					this.getView().byId("FreeholdGrpA").setSelected(true);
					this.getView().byId("LeasedGrpA").setSelected(false);
				}

				if (oDataSelected.LeasedorfreeholdIs === "Leased") {
					this.getView().byId("LeasedGrpC").setSelected(true);
					this.getView().byId("FreeholdGrpC").setSelected(false);
				} else {
					this.getView().byId("FreeholdGrpC").setSelected(true);
					this.getView().byId("LeasedGrpC").setSelected(false);
				}

				if (oDataSelected.RelationwithnmdcIp === "Yes") {
					this.getView().byId("YesGrpB").setSelected(true);
					this.getView().byId("NoGrpB").setSelected(false);
				} else {
					this.getView().byId("NoGrpB").setSelected(true);
					this.getView().byId("YesGrpB").setSelected(false);
				}

				if (oDataSelected.RelationwithnmdcIs === "Yes") {
					this.getView().byId("YesGrpD").setSelected(true);
					this.getView().byId("NoGrpD").setSelected(false);
				} else {
					this.getView().byId("NoGrpD").setSelected(true);
					this.getView().byId("YesGrpD").setSelected(false);
				}

				this.getView().byId("EMGO").setValue(oDataSelected.OwnershipPerIs);
				this.getView().byId("magd").setValue(oDataSelected.MoaPsgmlIs);
				//	this.getView().byId("IS_Property_AprRemarks").setValue(oDataSelected.ZPAGE4TEXT1);
				//	this.getView().byId("propertgypr").setValue(oDataSelected.ZPAGE4TEXT1);
				// this.getView().byId("IS_SRC_AprRemarks").setValue(oDataSelected.ZPAGE4TEXT2);
				//	this.getView().byId("srcdoc").setValue(oDataSelected.SourceIs);
				this.getView().byId("refn").setValue(oDataSelected.RefNumDateIs);
				this.getView().byId("partyadd").setValue(oDataSelected.PartyNameAddIs);
				this.getView().byId("relationint").setValue(oDataSelected.RelPartyEmpIs);
				this.getView().byId("detaild").setValue(oDataSelected.DetailsDealerIs);
				this.getView().byId("declareem").setValue(oDataSelected.AnyOtherFactsIs);

				if (oDataSelected.PageIndicator === "Priorview") {
					//	this.getView().byId("propertgypr").setValue(oDataSelected.ZPAGE4TEXT1);
					// this.getView().byId("IS_SRC_AprRemarks").setValue(oDataSelected.ZPAGE4TEXT2);
					this.getView().byId("priorappIP").setVisible(false);
					this.getView().byId("priorappIPLabel").setVisible(false);

					this.getView().byId("priorappMP").setVisible(false);
					this.getView().byId("priorappMPLabel").setVisible(false);

					this.getView().byId("priorappIS").setVisible(false);
					this.getView().byId("priorappISLabel").setVisible(false);

					this.getView().byId("priorappMS").setVisible(false);
					this.getView().byId("priorappMSLabel").setVisible(false);
				}

				if (oDataSelected.PageIndicator === "Postview") {
					//	this.getView().byId("propertgypr").setValue(oDataSelected.ZPOST4TEXT1);
					// this.getView().byId("IS_SRC_AprRemarks").setValue(oDataSelected.ZPOST4TEXT2);
					this.getView().byId("priorappIP").setVisible(true);
					this.getView().byId("priorappIPLabel").setVisible(true);

					this.getView().byId("priorappMP").setVisible(true);
					this.getView().byId("priorappMPLabel").setVisible(true);

					this.getView().byId("priorappIS").setVisible(true);
					this.getView().byId("priorappISLabel").setVisible(true);

					this.getView().byId("priorappMS").setVisible(true);
					this.getView().byId("priorappMSLabel").setVisible(true);
				}
				if (oDataSelected.PageIndicator === "Preapprove") {
					//	this.getView().byId("propertgypr").setValue(oDataSelected.ZPRE4TEXT1);
					// this.getView().byId("IS_SRC_AprRemarks").setValue(oDataSelected.ZPRE4TEXT2);
				}

				if (oDataSelected.salarysavingip !== '') {
					this.getView().byId("SalSavPriorIP").setValue(parseInt(oDataSelected.salarysavingip));
				}
				if (oDataSelected.bankcompanyloanip !== '') {
					this.getView().byId("BankComPriorIP").setValue(parseInt(oDataSelected.bankcompanyloanip));
				}
				if (oDataSelected.goldotherloanip !== '') {
					this.getView().byId("GoldOthrPriorIP").setValue(parseInt(oDataSelected.goldotherloanip));
				}
				if (oDataSelected.sogip !== '') {
					this.getView().byId("SellPriorIP").setValue(parseInt(oDataSelected.sogip));
				}
				if (oDataSelected.loanfrmrelativesip !== '') {
					this.getView().byId("LoanRelPriorIP").setValue(parseInt(oDataSelected.loanfrmrelativesip));
				}

				// this.getView().byId("SalSavPriorIP").setValue((oDataSelected.salarysavingip));
				//  this.getView().byId("BankComPriorIP").setValue(oDataSelected.bankcompanyloanip);
				// this.getView().byId("GoldOthrPriorIP").setValue((oDataSelected.goldotherloanip));
				// this.getView().byId("SellPriorIP").setValue((oDataSelected.sogip));
				//  this.getView().byId("LoanRelPriorIP").setValue((oDataSelected.loanfrmrelativesip));

				if (oDataSelected.bankstatementip === 'X') {
					this.getView().byId("BankCBIP").setSelected(true);
				} else {
					this.getView().byId("BankCBIP").setSelected(false);
				}
				if (oDataSelected.loansanctionletetrip === 'X') {
					this.getView().byId("LoanCBIP").setSelected(true);
				} else {
					this.getView().byId("LoanCBIP").setSelected(false);
				}
				if (oDataSelected.agreementsalecpyip === 'X') {
					this.getView().byId("AgrCBIP").setSelected(true);
				} else {
					this.getView().byId("AgrCBIP").setSelected(false);
				}
				if (oDataSelected.estimationvaluationip === 'X') {
					this.getView().byId("EstCBIP").setSelected(true);
				} else {
					this.getView().byId("EstCBIP").setSelected(false);
				}
				if (oDataSelected.latestpayslipip === 'X') {
					this.getView().byId("LatPayCBIP").setSelected(true);
				} else {
					this.getView().byId("LatPayCBIP").setSelected(false);
				}
				if (oDataSelected.otherdocumentsip === 'X') {
					this.getView().byId("OthrDocCBIP").setSelected(true);
				} else {
					this.getView().byId("OthrDocCBIP").setSelected(false);
				}
				if (oDataSelected.priorapprovalcpyip === 'X') {
					this.getView().byId("priorappIP").setSelected(true);
				} else {
					this.getView().byId("priorappIP").setSelected(false);
				}

				// this.getView().byId("SalSavPriorIS").setValue(parseInt(oDataSelected.salarysavingis));
				// this.getView().byId("BankComPriorIS").setValue(oDataSelected.bankcompanyloanis);
				// this.getView().byId("GoldOthrPriorIS").setValue(oDataSelected.goldotherloanis);
				// this.getView().byId("SellPriorIS").setValue(oDataSelected.sogis);
				// this.getView().byId("LoanRelPriorIS").setValue(oDataSelected.loanfrmrelativesis);

				if (oDataSelected.salarysavingis !== '') {
					this.getView().byId("SalSavPriorIS").setValue(parseInt(oDataSelected.salarysavingis));
				}
				if (oDataSelected.bankcompanyloanis !== '') {
					this.getView().byId("BankComPriorIS").setValue(parseInt(oDataSelected.bankcompanyloanis));
				}
				if (oDataSelected.goldotherloanis !== '') {
					this.getView().byId("GoldOthrPriorIS").setValue(parseInt(oDataSelected.goldotherloanis));
				}
				if (oDataSelected.sogis !== '') {
					this.getView().byId("SellPriorIS").setValue(parseInt(oDataSelected.sogis));
				}
				if (oDataSelected.loanfrmrelativesis !== '') {
					this.getView().byId("LoanRelPriorIS").setValue(parseInt(oDataSelected.loanfrmrelativesis));
				}

				if (oDataSelected.bankstatementis === 'X') {
					this.getView().byId("BankCBIS").setSelected(true);
				} else {
					this.getView().byId("BankCBIS").setSelected(false);
				}
				if (oDataSelected.loansanctionletetris === 'X') {
					this.getView().byId("LoanCBIS").setSelected(true);
				} else {
					this.getView().byId("LoanCBIS").setSelected(false);
				}
				if (oDataSelected.agreementsalecpyis === 'X') {
					this.getView().byId("AgrCBIS").setSelected(true);
				} else {
					this.getView().byId("AgrCBIS").setSelected(false);
				}
				if (oDataSelected.estimationvaluationis === 'X') {
					this.getView().byId("EstCBIS").setSelected(true);
				} else {
					this.getView().byId("EstCBIS").setSelected(false);
				}
				if (oDataSelected.latestpayslipis === 'X') {
					this.getView().byId("LatPayCBIS").setSelected(true);
				} else {
					this.getView().byId("LatPayCBIS").setSelected(false);
				}
				if (oDataSelected.otherdocumentsis === 'X') {
					this.getView().byId("OthrDocCBIS").setSelected(true);
				} else {
					this.getView().byId("OthrDocCBIS").setSelected(false);
				}
				if (oDataSelected.priorapprovalcpyis === 'X') {
					this.getView().byId("priorappIS").setSelected(true);
				} else {
					this.getView().byId("priorappIS").setSelected(false);
				}

				// this.getView().byId("SalSavPriorMP").setValue(oDataSelected.salarysavingmp);
				// this.getView().byId("BankComPriorMP").setValue(oDataSelected.bankcompanyloanmp);
				// this.getView().byId("GoldOthrPriorMP").setValue(oDataSelected.goldotherloanmp);
				// this.getView().byId("SellPriorMP").setValue(oDataSelected.sogmp);
				// this.getView().byId("LoanRelPriorMP").setValue(oDataSelected.loanfrmrelativesmp);

				if (oDataSelected.salarysavingmp !== '') {
					this.getView().byId("SalSavPriorMP").setValue(parseInt(oDataSelected.salarysavingmp));
				}
				if (oDataSelected.bankcompanyloanmp !== '') {
					this.getView().byId("BankComPriorMP").setValue(parseInt(oDataSelected.bankcompanyloanmp));
				}
				if (oDataSelected.goldotherloanmp !== '') {
					this.getView().byId("GoldOthrPriorMP").setValue(parseInt(oDataSelected.goldotherloanmp));
				}
				if (oDataSelected.sogmp !== '') {
					this.getView().byId("SellPriorMP").setValue(parseInt(oDataSelected.sogmp));
				}
				if (oDataSelected.loanfrmrelativesmp !== '') {
					this.getView().byId("LoanRelPriorMP").setValue(parseInt(oDataSelected.loanfrmrelativesmp));
				}

				if (oDataSelected.bankstatementmp === 'X') {
					this.getView().byId("BankCBMP").setSelected(true);
				} else {
					this.getView().byId("BankCBMP").setSelected(false);
				}
				if (oDataSelected.loansanctionletetrmp === 'X') {
					this.getView().byId("LoanCBMP").setSelected(true);
				} else {
					this.getView().byId("LoanCBMP").setSelected(false);
				}
				if (oDataSelected.agreementsalecpymp === 'X') {
					this.getView().byId("AgrCBMP").setSelected(true);
				} else {
					this.getView().byId("AgrCBMP").setSelected(false);
				}
				if (oDataSelected.estimationvaluationmp === 'X') {
					this.getView().byId("EstCBMP").setSelected(true);
				} else {
					this.getView().byId("EstCBMP").setSelected(false);
				}
				if (oDataSelected.latestpayslipmp === 'X') {
					this.getView().byId("LatPayCBMP").setSelected(true);
				} else {
					this.getView().byId("LatPayCBMP").setSelected(false);
				}
				if (oDataSelected.otherdocumentsmp === 'X') {
					this.getView().byId("OthrDocCBMP").setSelected(true);
				} else {
					this.getView().byId("OthrDocCBMP").setSelected(false);
				}

				if (oDataSelected.priorapprovalcpymp === 'X') {
					this.getView().byId("priorappMP").setSelected(true);
				} else {
					this.getView().byId("priorappMP").setSelected(false);
				}

				// this.getView().byId("SalSavPriorMS").setValue(oDataSelected.salarysavingms);
				// this.getView().byId("BankComPriorMS").setValue(oDataSelected.bankcompanyloanms);
				// this.getView().byId("GoldOthrPriorMS").setValue(oDataSelected.goldotherloanms);
				// this.getView().byId("SellPriorMS").setValue(oDataSelected.sogms);
				// this.getView().byId("LoanRelPriorMS").setValue(oDataSelected.loanfrmrelativesms);

				if (oDataSelected.salarysavingms !== '') {
					this.getView().byId("SalSavPriorMS").setValue(parseInt(oDataSelected.salarysavingms));
				}
				if (oDataSelected.bankcompanyloanms !== '') {
					this.getView().byId("BankComPriorMS").setValue(parseInt(oDataSelected.bankcompanyloanms));
				}
				if (oDataSelected.goldotherloanms !== '') {
					this.getView().byId("GoldOthrPriorMS").setValue(parseInt(oDataSelected.goldotherloanms));
				}
				if (oDataSelected.sogms !== '') {
					this.getView().byId("SellPriorMS").setValue(parseInt(oDataSelected.sogms));
				}
				if (oDataSelected.loanfrmrelativesms !== '') {
					this.getView().byId("LoanRelPriorMS").setValue(parseInt(oDataSelected.loanfrmrelativesms));
				}

				if (oDataSelected.bankstatementms === 'X') {
					this.getView().byId("BankCBMS").setSelected(true);
				} else {
					this.getView().byId("BankCBMS").setSelected(false);
				}
				if (oDataSelected.loansanctionletetrms === 'X') {
					this.getView().byId("LoanCBMS").setSelected(true);
				} else {
					this.getView().byId("LoanCBMS").setSelected(false);
				}
				if (oDataSelected.agreementsalecpyms === 'X') {
					this.getView().byId("AgrCBMS").setSelected(true);
				} else {
					this.getView().byId("AgrCBMS").setSelected(false);
				}
				if (oDataSelected.estimationvaluationms === 'X') {
					this.getView().byId("EstCBMS").setSelected(true);
				} else {
					this.getView().byId("EstCBMS").setSelected(false);
				}
				if (oDataSelected.latestpayslipmp === 'X') {
					this.getView().byId("LatPayCBIP").setSelected(true);
				} else {
					this.getView().byId("LatPayCBMS").setSelected(false);
				}
				if (oDataSelected.otherdocumentsmp === 'X') {
					this.getView().byId("OthrDocCBMS").setSelected(true);
				} else {
					this.getView().byId("OthrDocCBMS").setSelected(false);
				}
				if (oDataSelected.priorapprovalcpyms === 'X') {
					this.getView().byId("priorappMS").setSelected(true);
				} else {
					this.getView().byId("priorappMS").setSelected(false);
				}

				/*	this.getView().byId("refno").setValue(oDataSelected.ReferenceNo);
								this.getView().byId("emp").setValue(oDataSelected.EmployeeID);
								this.getView().byId("reqfor").setValue(oDataSelected.RelationName);
								this.getView().byId("relation").setValue(oDataSelected.Relation);
								this.getView().byId("name").setValue(oDataSelected.AppliedFor);
								this.getView().byId("age").setValue(oDataSelected.Age);
								this.getView().byId("gender").setValue(oDataSelected.Gender);
								this.getView().byId("aadharno").setValue(oDataSelected.Aadharno);
								this.getView().byId("loc").setValue(oDataSelected.HospitalLoc);
								this.getView().byId("hosp").setValue(oDataSelected.HospitalName);
								this.getView().byId("hospname").setValue(oDataSelected.HospitalName);
								this.getView().byId("state").setValue(oDataSelected.STATE);
								this.getView().byId("city").setValue(oDataSelected.HospitalLoc);
								this.getView().byId("pincode").setValue(oDataSelected.PINCODE);
								this.getView().byId("pack").setValue(oDataSelected.Package);
								this.getView().byId("package").setValue(oDataSelected.Package);
								this.getView().byId("history").setValue(oDataSelected.MedicalHistory);
								this.getView().byId("status").setValue(oDataSelected.Status);*/

				this.getView().byId("movable_purchase").setVisible(true);
				this.getView().byId("movable_sales").setVisible(true);
				this.getView().byId("immovable_purchase").setVisible(true);
				this.getView().byId("immovable_sales").setVisible(true);
				this.getView().byId("Remarks").setVisible(true);
				this.getView().byId("details").setVisible(true);
				if (oSelectedItem.getFirstStatus().getText() === "Submitted") {
					this.getView().byId("approve").setEnabled(true);
					this.getView().byId("reject").setEnabled(true);
				} else {
					this.getView().byId("approve").setEnabled(false);
					this.getView().byId("reject").setEnabled(false);
				}
				this._onReadEmpDetails(oDataSelected);
				this._getFileSet(oDataSelected.RefNumber);

			}
		},

		_getFileSet: function(refNum) {
			var that = this;
			var oModelEmp = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			var oModelFileSet = new sap.ui.model.json.JSONModel();
			var Filter1 = new sap.ui.model.Filter('RequestId', 'EQ', refNum);
			oModelEmp.read("/FileSet", {
				filters: [Filter1],
				success: function(oData, oResponse) {
					oModelFileSet.setData(oData);
					// that.getView().byId("UploadCollection").setModel(oModelFileSet);
					// that.getView().byId("UploadCollection1").setModel(oModelFileSet);
					// that.getView().byId("UploadCollection2").setModel(oModelFileSet);
					// that.getView().byId("UploadCollection3").setModel(oModelFileSet);
					// that.getView().byId("UploadCollection4").setModel(oModelFileSet);
					// that.getView().byId("UploadCollection5").setModel(oModelFileSet);
					// that.getView().byId("UploadCollection6").setModel(oModelFileSet);
					// that.getView().byId("UploadCollection7").setModel(oModelFileSet);
					for (var i = 0; i < oData.results.length; i++) {
						if (oData.results[i].Indicator == "OTHERDOC" && oData.results[i].TabInd == "MOVPUR") {
							oData.results[i].comments = othrDocCommentsMP;
						}
						if (oData.results[i].Indicator == "OTHERDOC" && oData.results[i].TabInd == "IMMOVPUR") {
							oData.results[i].comments = othrDocCommentsIP;
						}
						if (oData.results[i].Indicator == "OTHERDOC" && oData.results[i].TabInd == "MOVSAL") {
							oData.results[i].comments = othrDocCommentsMS;
						}
						if (oData.results[i].Indicator == "OTHERDOC" && oData.results[i].TabInd == "IMMOVSAL") {
							oData.results[i].comments = othrDocCommentsIS;
						}
					}
					that.getView().byId("LinkBankIP").setModel(oModelFileSet);
					that.getView().byId("LinkBankIS").setModel(oModelFileSet);
					that.getView().byId("LinkBankMS").setModel(oModelFileSet);
					that.getView().byId("LinkBankMP").setModel(oModelFileSet);

					sap.ui.core.BusyIndicator.hide();
				},
				error: function(err) {
					MessageBox.error("Error while fetching fileset data.");
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},

		_onReadEmpDetails: function(oData) {
			var othis = this;
			var emp = oData.EmployeeID;
			var emp = oData.Pernr;
			var emp1 = oData.RefNumber;
			var emdata = {};
			emdata.EmpName = oData.EmpName;
			emdata.EmpDesig = oData.EmpDesig;
			emdata.Pernr = oData.Pernr;
			emdata.PrsntBasicSlry = oData.PrsntBasicSlry;
			emdata.RefNumber = oData.RefNumber;
			sap.ui.core.BusyIndicator.show(0);
			var oModelEmp = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_APPROVER_SRV/", true);
			this.getView().setModel(oModelEmp);
			//var entity = "/Annual_Property_ApproverSet(UserId='" + emp + "')";
			//var entity = "/Annual_Property_ApproverSet(UserID='" + emp1 + "')";
			var entity = "/Annual_Property_ApproverSet";
			oModelEmp.read(entity, {
				success: function(oDataEmp) {
					var oModelEmpData = new sap.ui.model.json.JSONModel();
					debugger;
					othis.getView().setModel(oModelEmpData, "oModelEmp");
					oModelEmpData.setData(emdata);
					//	oModelEmpData.setData(oDataEmp);
					othis.getView().setModel(oModelEmpData, "oModelEmp");
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(oError) {
					sap.m.MessageBox.error("Error in fetching data.Please try again");
					sap.ui.core.BusyIndicator.hide();
				}
			});
			//	this.onSelectState();
		},

		_onRead: function(othis) {
			sap.ui.core.BusyIndicator.show(0);
			var that = this;
			var oModelMHC = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_APPROVER_SRV/", true);
			othis.getView().setModel(oModelMHC);
		//	var oParameter = '10002439'; // manisha hardcoded
			var oParameter = sap.ushell.Container.getService("UserInfo").getId();

			//	Filter = new sap.ui.model.Filter('UserId', 'EQ', 'UserId'); 
			// 	Filter = new sap.ui.model.Filter('Approver2Empid', 'EQ', oParameter); 
			// var	Filter1 = new sap.ui.model.Filter('ApproverEmpid', 'EQ', oParameter); 

			Filter = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter('ApproverEmpid', 'EQ', oParameter),
					new sap.ui.model.Filter('Approver2Empid', 'EQ', oParameter)
				],
				and: false
			});

			// var	Filter2 = new sap.ui.model.Filter('ApproverStatus', 'EQ', 'Approved');
			// var	Filter1 = new sap.ui.model.Filter('Approver2Status', 'NE', 'Approved');
			oModelMHC.read("/Annual_Property_ApproverSet", {
				filters: [Filter],
				success: function(oData, oResponse) {
					debugger;
					var oModel = new sap.ui.model.json.JSONModel();

					if (oData.results !== undefined) {
						for (var i = 0; i < oData.results.length; i++) {
							if (oData.results[i].Approver2Status !== "") {
								if (oData.results[i].Approver2Status  === "Rejected") {
										oData.results[i].customStatus = "Rejected" ;
								}else{
								if (parseInt(oParameter) === parseInt(oData.results[i].ApproverEmpid)) {
									oData.results[i].customStatus = oData.results[i].Approver2Status === "Submitted" ? "With Approver 2" : oData.results[i].Approver2Status;
								} else if (parseInt(oParameter) === parseInt(oData.results[i].Approver2Empid)) {
									oData.results[i].customStatus = oData.results[i].Approver2Status;
								}
								}
							
							} else if (oData.results[i].ApproverStatus !== "") {
									if (oData.results[i].ApproverStatus  === "Rejected") {
										oData.results[i].customStatus = "Rejected" ;
								}else{
								oData.results[i].customStatus = oData.results[i].ApproverStatus;
								}
							} else {
								oData.results[i].customStatus = "Submitted";
							}
						}
					}

					oModel.setData(oData);
					othis.getView().setModel(oModel, "oModelReq");
					sap.ui.core.BusyIndicator.hide();
					//manisha start

				},
				error: function(error) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageBox.error("User Id is not assigned to Valid Employee ID.");
					window.history.go(-1);
				}
			});
		},
		onApprove: function() {
			var remarks = this.getView().byId("remarks").getValue();
			/*var StateName = this.getView().byId("state").getValue();
			var Hsploc = this.getView().byId("city").getValue();
			var Pincode = this.getView().byId("pincode").getValue();
			var Hspname = this.getView().byId("hospname").getValue();
			var pack = this.getView().byId("package").getSelectedKeys();
			
			if (!StateName) {
				sap.m.MessageBox.error("Please select State.");
				return;
			}

			if (!Hsploc) {
				sap.m.MessageBox.error("Please select City.");
				return;
			}
			if (!Pincode) {
				sap.m.MessageBox.error("Please select Pincode.");
				return;
			}
			if (!Hspname) {
				sap.m.MessageBox.error("Please select Hospital Name.");
				return;
			}
			if (!pack) {
				sap.m.MessageBox.error("Please select Hospital Name.");
				return;
			}
		*/
			if (!remarks) {
				sap.m.MessageBox.error("Remarks can not be initial.");
				return;
			}
			this._onUpdateApprove(4);
		},

		onReject: function() {
			var remarks = this.getView().byId("remarks").getValue();
			if (!remarks) {
				sap.m.MessageBox.error("Remarks can not be initial.");
				return;
			}
			this._onUpdateReject(5);
		},

		_onUpdateApprove: function() {
			//	debugger;
			var othis = this;
			// for approval 2

		//	var loginUser = '142'; // hardcoded manisha
			var loginUser = sap.ushell.Container.getService("UserInfo").getId();
			var vals = "";
			if (parseInt(loginUser) === parseInt(oDataSelected.ApproverEmpid)) {
				oDataSelected.ApproverEmpid = loginUser;
				oDataSelected.Approver2Empid = "";
				oDataSelected.ApproverStatus = "Approved"; 
			//Movable logic added so that only for POST req should go directly to approver 2 after approver 1(Skip final approval screen)
				if(oDataSelected.TabInd === "MOVPUR" || oDataSelected.TabInd === "MOVSAL"){
								oDataSelected.Approver2Status = "Submitted";
				}else{
										oDataSelected.Approver2Status = "";
			
				}
				oDataSelected.AprRemarks = this.getView().byId("remarks").getValue();
				delete oDataSelected.customStatus;
				vals = "/Annual_Property_ApproverSet(ApproverEmpid='" + oDataSelected.ApproverEmpid + "',Pernr='" + oDataSelected.Pernr +
					"',RefNumber='" + oDataSelected.RefNumber + "')";

			} else if (parseInt(loginUser) === parseInt(oDataSelected.Approver2Empid)) {
				oDataSelected.ApproverEmpid = "";
				oDataSelected.Approver2Empid = loginUser;
				oDataSelected.Approver2Status = "Approved"; //manisha commented after approver2 logic added
				oDataSelected.Status = "Approved"; //manisha commented after approver2 logic added
				oDataSelected.Approver2Remarks = this.getView().byId("remarks").getValue();
				delete oDataSelected.customStatus;
				vals = "/Annual_Property_ApproverSet(Approver2Empid='" + oDataSelected.Approver2Empid + "',Pernr='" + oDataSelected.Pernr +
					"',RefNumber='" + oDataSelected.RefNumber + "')";

			}

			sap.ui.core.BusyIndicator.show(0);
			var oModelReq1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_APPROVER_SRV/", true);
			var vals = "/Annual_Property_ApproverSet(Emp='" + oDataSelected.Pernr + "',ReferenceNo='" + oDataSelected.RefNumber +	"',Mode='')";
				var vals = "/Annual_Property_ApproverSet(Approver2Empid='"+ oDataSelected.Approver2Empid + "',Pernr='"+ oDataSelected.Pernr + "',RefNumber='" + oDataSelected.RefNumber +"')";
			oModelReq1.update(vals, oDataSelected, null, function() {
					sap.m.MessageBox.success("Request updated successfully.");
				},
				function() {
					othis._onRead(othis);
					sap.m.MessageBox.error("Error in updating data, Please try again");
				}
			);
			sap.ui.core.BusyIndicator.hide();
			othis._onRead(othis);
			othis._onClear();
		},

		_onUpdateReject: function() {

			var othis = this;
			// oDataSelected.Status = "Rejected";
			// oDataSelected.AprRemarks = this.getView().byId("remarks").getValue();

		//		var loginUser = '177'; // hardcoded manisha
			var loginUser = sap.ushell.Container.getService("UserInfo").getId();
			var vals = "";
			if (parseInt(loginUser) === parseInt(oDataSelected.ApproverEmpid)) {
				oDataSelected.ApproverEmpid = loginUser;
				oDataSelected.Approver2Empid = "";
				oDataSelected.ApproverStatus = "Rejected"; //manisha commented after approver2 logic added
				oDataSelected.AprRemarks = this.getView().byId("remarks").getValue();
				delete oDataSelected.customStatus;
				vals = "/Annual_Property_ApproverSet(ApproverEmpid='" + oDataSelected.ApproverEmpid + "',Pernr='" + oDataSelected.Pernr +
					"',RefNumber='" + oDataSelected.RefNumber + "')";

			} else if (parseInt(loginUser) === parseInt(oDataSelected.Approver2Empid)) {
				oDataSelected.ApproverEmpid = "";
				oDataSelected.Approver2Empid = loginUser;
				oDataSelected.Approver2Status = "Rejected"; //manisha commented after approver2 logic added
				oDataSelected.Status = "Rejected"; //manisha commented after approver2 logic added
				oDataSelected.Approver2Remarks = this.getView().byId("remarks").getValue();
				delete oDataSelected.customStatus;
				vals = "/Annual_Property_ApproverSet(Approver2Empid='" + oDataSelected.Approver2Empid + "',Pernr='" + oDataSelected.Pernr +
					"',RefNumber='" + oDataSelected.RefNumber + "')";

			}

			/*	oDataSelected.ApprLoc = this.getView().byId("city").getValue();
				oDataSelected.ApprHsp = this.getView().byId("hospname").getValue();
				oDataSelected.STATE = this.getView().byId("state").getValue();
				oDataSelected.PINCODE = this.getView().byId("pincode").getValue();
				oDataSelected.LIFNR = this.getView().byId("hospname").getSelectedKey();
				oDataSelected.BLAND = this.getView().byId("state").getSelectedKey();
				var pack = this.getView().byId("package").getSelectedKeys();
				oDataSelected.ApprPack = pack.join(",");*/
			sap.ui.core.BusyIndicator.show(0);
			var oModelReq1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_APPROVER_SRV/", true);
			//	var vals = "/Annual_Property_ApproverSet(EmployeeID='" + oDataSelected.EmployeeID + "',ReferenceNo='" + oDataSelected.ReferenceNo + "',Mode='')";
			oModelReq1.update(vals, oDataSelected, null, function() {
					sap.m.MessageBox.success("Request updated successfully.");
				},
				function() {
					othis._onRead(othis);
					sap.m.MessageBox.error("Error in updating data, Please try again");
				}
			);
			sap.ui.core.BusyIndicator.hide();
			othis._onRead(othis);
			othis._onClear();
		},

		onDownload: function(oEvent) {
			var othis = this;
			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("oModMedLet");
			var sPath = oContext.getPath();
			var oModel = oContext.getModel();
			oDataSelected = oModel.getProperty(sPath);
			if (oDataSelected) {
				var oUri = "/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_APPROVER_SRV/FileSet(Key='" + oDataSelected.FileName + "')/$value";
				sap.m.URLHelper.redirect(oUri, true);
			}
		},

		_onClear: function() {
			this.getView().byId("remarks").setValue("");
			this.getView().byId("approve").setEnabled(false);
			this.getView().byId("reject").setEnabled(false);
			// this.getView().byId("movable_purchase").setEnabled(false);
			// this.getView().byId("movable_sales").setEnabled(false);
			// this.getView().byId("immovable_purchase").setEnabled(false);
			// this.getView().byId("immovable_sales").setEnabled(false);
			// this.getView().byId("details").setEnabled(false);
			// this.getView().byId("master").setEnabled(false);

			/*			
						this.getView().byId("state").setValue("");
						this.getView().byId("city").setValue("");
						this.getView().byId("pincode").setValue("");
						this.getView().byId("hospname").setValue("");
						this.getView().byId("package").setValue("");
						this.getView().byId("form").setVisible(false);
						this.getView().byId("details").setVisible(false);
					*/
		}
	});
});