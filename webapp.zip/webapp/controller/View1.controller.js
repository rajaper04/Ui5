sap.ui.define([
	'jquery.sap.global',
	"sap/ui/core/mvc/Controller", "sap/ui/model/Filter",  './Formatter'
], function(jQuery, Controller, Filter, Formatter){
	"use strict";

	return Controller.extend("ZHR_ANPROP_APPR.controller.View1", {
		onInit: function() {
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._onRead(this);

		},
		onBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("FirstView");
		},
		onFilterClick: function() {
			this.dialogs = sap.ui.xmlfragment("ZHR_ANPROP_APPR.model.filter", this);
			this.dialogs.open();

		},
		handleFilterDialogConfirm: function (oEvent) {
 			var oTable = this.byId("reqtable"),
 				mParams = oEvent.getParameters(),
 				oBinding = oTable.getBinding("items"),
 				aFilters = [];
 				var sValue = oEvent.getSource()._filterDetailList.getSelectedItem().getTitle();
             var oFilter = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, sValue);
             aFilters.push(oFilter);
             oBinding.filter(aFilters);
 			// mParams.filterItems.forEach(function (oItem) {
 			// 	window.globalVariable = oItem.getKey().split("");
 			// 	var aSplit = oItem.getKey().split("___"),
 			// 		sPath = aSplit[0],
 			// 		sOperator = aSplit[1],
 			// 		sValue1 = aSplit[2],
 			// 		oFilter = new sap.ui.model.Filter(sPath, sOperator, sValue1);
 			// 	aFilters.push(oFilter);
 			// });
 		//	oBinding.filter(aFilters);
 		
 		},
		
		// onCancelRequest: function(oEvent){
		// 	var oSelectedItem = oEvent.getSource();
		// 	var oContext = oSelectedItem.getBindingContext("oModelReq");
		// 	var sPath = oContext.getPath();
		// 	var oModel = oContext.getModel();
		// 	var oDataSelected = oModel.getProperty(sPath);
		// 	var othis = this;
		// 	oDataSelected.Status = '8';
		// 	sap.ui.core.BusyIndicator.show(0);
		// 	var oModelReq = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAILS_SRV/", true);
		// 	var vals = "/HealthReqSet(EmployeeID='" + oDataSelected.EmployeeID + "',ReferenceNo='" + oDataSelected.ReferenceNo +
		// 		"',Mode='')";
		// 	oModelReq.update(vals, oDataSelected, null, function() {
		// 			sap.m.MessageBox.success("Request updated successfully.");
		// 		},
		// 		function() {
		// 			othis.onReadRequest();
		// 			sap.m.MessageBox.error("Error in updating data, Please try again");
		// 		}   
		// 	);
		// 	sap.ui.core.BusyIndicator.hide();
		// 	othis.onReadRequest();


		onDownload: function(oEvent) {
			debugger;
			var othis = this;
			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("oModelReq");
			var sPath = oContext.getPath();
			var oModel = oContext.getModel();
			var oDataSelected = oModel.getProperty(sPath);
			if (oDataSelected) {
					debugger;
				var oUri = "/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_APPROVER_SRV/FileSet(Key='"  + oDataSelected.ReferenceNo + "')/$value";
			//	var oUri = "/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/FileSet(Key='{FileName}')/$value";
				
				sap.m.URLHelper.redirect(oUri, true);
			}
		},

		_onRead: function(othis) {
			sap.ui.core.BusyIndicator.show(0);
			var oModelMHC = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_APPROVER_SRV/", true);
			othis.getView().setModel(oModelMHC);
			var oParameter = 'UserId';
			Filter = new sap.ui.model.Filter('UserId', 'EQ', oParameter);
			// var oParameter2 = 'ALL';
			// var Filter2 = new sap.ui.model.Filter('STATE', 'EQ', oParameter2);
			oModelMHC.read("/Annual_Property_ApproverSet", {
				filters: [Filter],
				success: function(oData, oResponse) {
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					othis.getView().setModel(oModel, "oModelReq");
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(error) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageBox.error("Error while loading data.");
					window.history.go(-1);
				}
			});
		}
	});
});