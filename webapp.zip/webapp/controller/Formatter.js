sap.ui.define(function() {
	"use strict";

	var Formatter = {

	
			statusState: function(sStatus) {
				if ((sStatus) === "Approved") {
					return "Success";
				} else if ((sStatus) === "Submitted") {
					return "Warning";
				}  else if ((sStatus) === "With Approver 1") {
					return "Warning";
				}  else if ((sStatus) === "With Approver 2") {
					return "Warning";
				} else if ((sStatus) === "Rejected") {
					return "Error";
				}
			},
			
				IndicatorText:  function (ind) {
				if (ind === "BANK") {
					return "Bank Statement";
				} 
					if (ind === "LOAN") {
					return "Loan Sanction Letter, if any";
				} 
					if (ind === "AGREEMENT") {
					return "Agreement /sale deed, if any";
				} 
					if (ind === "ESTIMATION") {
					return "Estimation/Valuation Report";
				} 
					if (ind === "LATESTPAY") {
					return "Latest Payslip Copy";
				} 
					if (ind === "OTHERDOC") {
					return "Other documents (please specify)";
				} 
					if (ind === "PRIOR") {
					return "Prior Approval Copy";
				}
					
				}, 
			
				IndicatorTextCom:  function (ind) {
					if (ind === "OTHERDOC") {
					return "comments";
				} 
			},
	
			
				Tabindicator: function(sInd) {
				if ((sInd) === "MOVPUR") {
					return "Movable Purchase";
				} else if ((sInd) === "MOVSAL") {
					return "Movable Sales";
				} else if ((sInd) === "IMMOVPUR") {
					return "Immovable Purchase";
				}else if ((sInd) === "IMMOVSAL") {
					return "Immovable Sales";
				}
			},
			buildFileUrl: function (sFileName,sRequest) {
				if (!sFileName) return "";
				if (!sRequest) return "";
				var vKey = "FileName='" + encodeURIComponent(sFileName) + "'" + ",RequestId='" + encodeURIComponent(sRequest) + "'";
				return "/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/FileSet(" + vKey + ")/$value";
			}
			
		
		
	};

	return Formatter;

}, /* bExport= */ true);