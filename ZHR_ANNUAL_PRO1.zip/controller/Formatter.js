sap.ui.define(function() {
	"use strict";

	var Formatter = {

		status :  function (sStatus) {
				if (sStatus === "Submitted") {
					return "Success";
				} else if (sStatus === "Out of Stock") {
					return "Warning";
				} else if (sStatus === "Discontinued"){
					return "Error";
				} else {
					return "None";
				}
		},
		IndicatorText:  function (ind) {
				if (ind === "BANK") {
					return "Bank Statement";
				} 
					if (ind === "LOAN") {
					return "Loan Sanction Letter, if any";
				} 
					if (ind === "AGREEMENT") {
					return "Agreement /sale deed";
				} 
					if (ind === "ESTIMATION") {
					return "Estimation/Valuvation Report Valuvation Report(After completion of construction of house/Flat/Ready built House)";
				} 
					if (ind === "LATESTPAY") {
					return "Latest Payslip Copy";
				} 
					if (ind === "OTHERDOC") {
					return "Other documents (please specify)";
				} 
					if (ind === "PRIOR") {
					return "Prior Approval Copy";
				} 
		},
		
		ReqType:  function (page) {
				if (page === "Priorview") {
					return "Prior";
				} else if (page === "Postview") {
					return "Post";
				} else if (page === "Preapprove"){
					return "Pre - approve";
				} 
		},
		
		generateCopyState: function(sStatus) {
				if ((sStatus) === "Approved") {
					return true;
				} else {
					return false;
				}
			},
		
			statusState: function(sStatus) {
				if ((sStatus) === "Approved" || sStatus === "Approved by Approver 1") {
					return "Success";
				} else if ((sStatus) === "Submitted") {
					return "Warning";
				}  else if ((sStatus) === "Pending with Approver 1") {
					return "Warning";
				}  else if ((sStatus) === "Pending with Approver 2") {
					return "Warning";
				} else if ((sStatus) === "Rejected" || (sStatus) === "Rejected by Approver 1") {
					return "Error";
				}
			},
			
			Tabindicator: function(sInd) {
				if ((sInd) === "MOVPUR") {
					return "Movable Purchase";
				} else if ((sInd) === "MOVSAL") {
					return "Movable Sales";
				} else if ((sInd) === "IMMOVPUR") {
					return "Immovable Purchase";
				}else if ((sInd) === "IMMOVSAL") {
					return "Immovable Sales";
				}
			}

		
	};

	return Formatter;

}, /* bExport= */ true);