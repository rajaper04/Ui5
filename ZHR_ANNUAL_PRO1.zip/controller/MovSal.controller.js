sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/base/util/deepExtend",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast"
], function(Controller, othis, MessageBox, deepExtend, Filter, oEmpData, oDep, Formatter, dateFormat, oDataSelected, fileName1_details,
	oPCTData, MessageToast) {
	"use strict";

	return Controller.extend("annualpropertyannualproperty.controller.MovSal", {
		onBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
		},

		onInit: function() {

			this.onRead();
			// var oUploadCollection = this.getView().byId('UploadCollection');
			//  oUploadCollection.setUploadUrl("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/FileSet");
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV", false);
			this.getView().setModel(oModel);

			// flag for validation of movpur
			this.attachmentFlagMovPur1 = false;
			this.attachmentFlagMovPur2 = false;
			// flag for validation of immovpur
			this.attachmentFlagMovSal1 = false;
			this.attachmentFlagMovSal2 = false;
			// flag for validation of movsal
			this.attachmentFlagImmovPur1 = false;
			this.attachmentFlagImmovPur2 = false;
			// flag for validation of immovsal
			this.attachmentFlagImmovSal1 = false;
			this.attachmentFlagImmovSal2 = false;

			dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMddHHmmss"
			});

			this.requestId = "";
		},

		onRead: function() {
			othis = this;
			sap.ui.core.BusyIndicator.show(0);

			var oModelEmp = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			this.getView().setModel(oModelEmp);
			//var Filter1 = [];
			oModelEmp.read("/Annual_PropertySet(UserId='DUMMY')", {
				success: function(oData, oResponse) {
					var oModelEmpData = new sap.ui.model.json.JSONModel();
					oModelEmpData.setData(oData);
					oEmpData = oData;
					othis.getView().setModel(oModelEmpData, "oModelEmployee");
					Filter = new sap.ui.model.Filter('UserId', 'EQ', oData.EmployeeNumber);
					//	Filter1 = new sap.ui.model.Filter('RefNumber', 'EQ', '1000000018');
					//RefNumber='1000000018'

					var oModelDep = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
					oModelDep.read("/Annual_PropertySet", {
						filters: [Filter],
						success: function(oDataDep, oResponseDep) {
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData(oDataDep);
							oDep = oDataDep.results;
							othis.getView().setModel(oModel, "oModelDep");
						},
						error: function(error) {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.error("User Id is not assigned to Valid Employee ID.");
						}
					});
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(err) {
					MessageBox.error("User Id is not assigned to Valid Employee ID.");
					sap.ui.core.BusyIndicator.hide();
				}
			});

			//FileSet data
			var oModelFileSet = new sap.ui.model.json.JSONModel();
			var oData = [];
			oData.results = [];
			oModelFileSet.setData(oData);
			var that = this;
			that.getView().byId("UploadCollection").setModel(oModelFileSet);
			that.getView().byId("UploadCollection1").setModel(oModelFileSet);
			that.getView().byId("UploadCollection2").setModel(oModelFileSet);
			that.getView().byId("UploadCollection3").setModel(oModelFileSet);
			that.getView().byId("UploadCollection4").setModel(oModelFileSet);
			that.getView().byId("UploadCollection5").setModel(oModelFileSet);
			that.getView().byId("UploadCollection6").setModel(oModelFileSet);
			that.getView().byId("UploadCollection7").setModel(oModelFileSet);

			// oModelEmp.read("/FileSet", {
			// 	success: function(oData, oResponse) {
			// 		oModelFileSet.setData(oData);
			// 		that.getView().byId("UploadCollection").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection1").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection2").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection3").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection4").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection5").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection6").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection7").setModel(oModelFileSet);
			// 		sap.ui.core.BusyIndicator.hide();
			// 	},
			// 	error: function(err) {
			// 		MessageBox.error("Error while fetching fileset data.");
			// 		sap.ui.core.BusyIndicator.hide();
			// 	}
			// });

		},

		onsubmit: function() {
			var entity = {};
			othis = this;
			var ofileset;
			//	debugger;
			//	common;

			if (this.requestId === "") {
				//	this.requestId = crypto.randomUUID();
				// this.requestId = Math.floor(Math.random() * 9000000000) + 1000000000; //10 digit random unique id
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			entity.Pernr = oEmpData.Pernr;

			entity.PageIndicator = othis.getView().byId("empname333").getValue();
			entity.RefNumber = this.requestId;
			//	debugger;
			var IconTabBarIdKey = othis.getView().byId("PriorIconTabBarId").getSelectedKey();
			//	entity.PropertyType=IconTabBarIdKey;
			entity.TabInd = IconTabBarIdKey;
			//	entity.Zindicator=othis.finFlag;
			//	entity.Zindicator="";

			if (
				//othis.getView().byId("priorRemarks1").getValue().length > 250 ||
				// othis.getView().byId("priorRemarks2").getValue().length > 250 ||
				//	othis.getView().byId("priorRemarks3").getValue().length > 250 ||
				// othis.getView().byId("priorRemarks4").getValue().length > 250 ||
				//	othis.getView().byId("priorRemarks5").getValue().length > 250 ||
				// othis.getView().byId("priorRemarks6").getValue().length > 250 ||
				othis.getView().byId("priorRemarks7").getValue().length > 250
				// othis.getView().byId("priorRemarks8").getValue().length > 250
			) {
				sap.m.MessageBox.error("Attachment remarks length can not exceed 250 characters.");
				return;
			}

			if (IconTabBarIdKey === "MOVPUR") {
				if (this.attachmentFlagMovPur1 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}

				if (this.attachmentFlagMovPur2 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}

			}

			if (IconTabBarIdKey === "MOVSAL") {
				if (this.attachmentFlagMovSal1 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}

				if (this.attachmentFlagMovSal2 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}
			}

			if (IconTabBarIdKey === "IMMOVSAL") {
				if (this.attachmentFlagImmovSal1 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}

				if (this.attachmentFlagImmovSal2 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}

				entity.salarysavingis = (othis.getView().byId("SalSavPriorIS").getValue());
				entity.bankcompanyloanis = (othis.getView().byId("BankComPriorIS").getValue());
				entity.goldotherloanis = (othis.getView().byId("GoldOthrPriorIS").getValue());
				entity.sogis = (othis.getView().byId("SellPriorIS").getValue());
				entity.loanfrmrelativesis = (othis.getView().byId("LoanRelPriorIS").getValue());

				entity.bankstatementis = othis.getView().byId("BankCBIS").getSelected() === true ? 'X' : '';
				entity.loansanctionletetris = othis.getView().byId("LoanCBIS").getSelected() === true ? 'X' : '';
				entity.agreementsalecpyis = othis.getView().byId("AgrCBIS").getSelected() === true ? 'X' : '';
				entity.estimationvaluationis = othis.getView().byId("EstCBIS").getSelected() === true ? 'X' : '';
				entity.latestpayslipis = othis.getView().byId("LatPayCBIS").getSelected() === true ? 'X' : '';
				entity.otherdocumentsis = othis.getView().byId("OthrDocCBIS").getSelected() === true ? 'X' : '';
				
				
			
					//validation for checkbox and file uploader
				if (entity.bankstatementis == "" || entity.loansanctionletetris == "" || entity.agreementsalecpyis == "" ||
					entity.estimationvaluationis == "" || entity.latestpayslipis == "" || entity.otherdocumentsis == "" ||
					othis.getView().byId("FUBankIS").getValue() == "" || othis.getView().byId("FULoanIS").getValue() == "" ||
					othis.getView().byId("FUAgrIS").getValue() == "" || othis.getView().byId("FUEstIS").getValue() == "" ||
					othis.getView().byId("FULatPayIS").getValue() == "" || othis.getView().byId("FUOthrDocIS").getValue() == "") {
					sap.m.MessageBox.error("Upload all documents and select all checkbox !! ");
					return;
				}

				othis.handleFileUploadPressIS();
			
				var EMGO = othis.getView().byId("EMGO").getValue();
				var EMMODep = othis.getView().byId("EMMODep").getValue();
				var EMMOOth = othis.getView().byId("EMMOOth").getValue();

				if ((parseInt(EMMOOth) + parseInt(EMMODep) + parseInt(EMGO)) !== 100) {
					sap.m.MessageBox.error("Total Ownership % of employee, dependent and others must be 100 %");
					return;
				}

			}

			if (IconTabBarIdKey === "IMMOVPUR") {
				if (this.attachmentFlagImmovPur1 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}

				if (this.attachmentFlagImmovPur2 === false) {
					sap.m.MessageBox.error("Attachment is mandatory.");
					return;
				}

				entity.salarysavingip = (othis.getView().byId("SalSavPriorIP").getValue());
				entity.bankcompanyloanip = (othis.getView().byId("BankComPriorIP").getValue());
				entity.goldotherloanip = (othis.getView().byId("GoldOthrPriorIP").getValue());
				entity.sogip = (othis.getView().byId("SellPriorIP").getValue());
				entity.loanfrmrelativesip = (othis.getView().byId("LoanRelPriorIP").getValue());

				entity.bankstatementip = othis.getView().byId("BankCBIP").getSelected() === true ? 'X' : '';
				entity.loansanctionletetrip = othis.getView().byId("LoanCBIP").getSelected() === true ? 'X' : '';
				entity.agreementsalecpyip = othis.getView().byId("AgrCBIP").getSelected() === true ? 'X' : '';
				entity.estimationvaluationip = othis.getView().byId("EstCBIP").getSelected() === true ? 'X' : '';
				entity.latestpayslipip = othis.getView().byId("LatPayCBIP").getSelected() === true ? 'X' : '';
				entity.otherdocumentsip = othis.getView().byId("OthrDocCBIP").getSelected() === true ? 'X' : '';

				//validation for checkbox and file uploader
				if (entity.bankstatementip == "" || entity.loansanctionletetrip == "" || entity.agreementsalecpyip == "" ||
					entity.estimationvaluationip == "" || entity.latestpayslipip == "" || entity.otherdocumentsip == "" ||
					othis.getView().byId("FUBankIP").getValue() == "" || othis.getView().byId("FULoanIP").getValue() == "" ||
					othis.getView().byId("FUAgrIP").getValue() == "" || othis.getView().byId("FUEstIP").getValue() == "" ||
					othis.getView().byId("FULatPayIP").getValue() == "" || othis.getView().byId("FUOthrDocIP").getValue() == "") {
					sap.m.MessageBox.error("Upload all documents and select all checkbox !! ");
					return;
				}
				
					othis.handleFileUploadPressIP();
			

				var EYMO = othis.getView().byId("EYMO").getValue();
				var EYMODep = othis.getView().byId("EYMODep").getValue();
				var EYMOOth = othis.getView().byId("EYMOOth").getValue();

				if ((parseInt(EYMOOth) + parseInt(EYMODep) + parseInt(EYMO)) !== 100) {
					sap.m.MessageBox.error("Total Ownership % of employee, dependent and others must be 100 %");
					return;
				}

			}

			//	entity.ZPAGE1TEXT1 = othis.getView().byId("priorRemarks1").getValue();
			// entity.ZPAGE1TEXT2 = othis.getView().byId("priorRemarks2").getValue();
			//	entity.ZPAGE2TEXT1 = othis.getView().byId("priorRemarks3").getValue();
			// entity.ZPAGE2TEXT2 = othis.getView().byId("priorRemarks4").getValue();
			//	entity.ZPAGE3TEXT1 = othis.getView().byId("priorRemarks5").getValue();
			// entity.ZPAGE3TEXT2 = othis.getView().byId("priorRemarks6").getValue();
			entity.ZPAGE4TEXT1 = othis.getView().byId("priorRemarks7").getValue();
			// entity.ZPAGE4TEXT2 = othis.getView().byId("priorRemarks8").getValue();

			//entity.EmpDesig = othis.getView().byId("Des").getValue();
			//entity.EmpDoj = othis.getView().byId("DOJ").getValue();
			//entity.ScaleOfPay = this.getView().byId("pay").getValue();
			//entity.PrsntBasicSlry = othis.getView().byId("salary").getValue();

			//Movable Purchase;
			entity.PropertyDescriMp = othis.getView().byId("pro").getValue();
			entity.MakeModelMp = othis.getView().byId("make").getValue();
			entity.TentativeDateMp = this.getView().byId("DP4").getValue();
			//	entity.PurchasePriceMp = othis.getView().byId("property").getValue();
			//	entity.SourceMp = othis.getView().byId("src").getValue();
			//	debugger;

			//	entity.FileSet = this.getView().byId("UploadCollection").getValue();
			//	entity.FileSet = othis.getView().byId("UploadCollection1").getItems();
			entity.RefNumDateMp = othis.getView().byId("ref").getValue();
			entity.PartyNameAddMp = othis.getView().byId("party").getValue();
			entity.RelPartyEmpMp = othis.getView().byId("relation").getValue();
			entity.DetailsDealerMp = this.getView().byId("detail").getValue();
			entity.AnyOtherFactsMp = othis.getView().byId("declare").getValue();

			//	Movable Sales set;
			entity.PropertyDescriMs = othis.getView().byId("des").getValue();
			entity.MakeModelMs = othis.getView().byId("makem").getValue();
			entity.TentativeDateMs = this.getView().byId("DP5").getValue();
			//entity.PurchasePriceMs = othis.getView().byId("price").getValue();
			//entity.SourceMs = othis.getView().byId("srcs").getValue();
			entity.RefNumDateMs = othis.getView().byId("refer").getValue();
			entity.PartyNameAddMs = othis.getView().byId("partyn").getValue();
			entity.RelPartyEmpMs = othis.getView().byId("relations").getValue();
			entity.DetailsDealerMs = this.getView().byId("det").getValue();
			entity.AnyOtherFactsMs = othis.getView().byId("dec").getValue();
			//	Immovable purchase set;		
			entity.PropertyDescriIp = othis.getView().byId("proper").getValue();
			entity.TentativeDateIp = this.getView().byId("DOYPsale").getValue();
			entity.CompleteAddrIp = othis.getView().byId("Coymp").getValue();

			entity.StateIP = othis.getView().byId("CoympSt").getValue();
			entity.DistrictIP = othis.getView().byId("CoympDis").getValue();
			entity.PinIP = othis.getView().byId("CoympPin").getValue();

			entity.OwnershipPerIp = othis.getView().byId("EYMO").getValue();
			//manisha
			entity.OwnershipDepndtIp = othis.getView().byId("EYMODep").getValue();
			entity.OwnershipotherIp = othis.getView().byId("EYMOOth").getValue();

			entity.MoaPsgmlIp = othis.getView().byId("matd").getValue();
			//entity.TentativePurIp = othis.getView().byId("prertypr").getValue();
			//entity.SourceIp = othis.getView().byId("srce").getValue();
			entity.RefNumDateIp = othis.getView().byId("refern").getValue();
			entity.PartyNameAddIp = othis.getView().byId("partyad").getValue();
			entity.RelPartyEmpIp = othis.getView().byId("Pne").getValue();
			entity.DetailsDealerIp = this.getView().byId("detailsd").getValue();
			entity.AnyOtherFactsIp = othis.getView().byId("declareemp").getValue();
			//	Immovable sales set;	
			entity.PropertyDescriIs = othis.getView().byId("desproIPS").getValue();
			//entity.TentativeDateIs = this.getView().byId("DOGPsale").getValue();
			entity.CompleteAddrIs = othis.getView().byId("Cogmp").getValue();

			entity.StateIS = othis.getView().byId("CogmpSt").getValue();
			entity.DistrictIS = othis.getView().byId("CogmpDis").getValue();
			entity.PinIS = othis.getView().byId("CogmpPin").getValue();

			entity.OwnershipPerIs = othis.getView().byId("EMGO").getValue();

			//manisha
			entity.OwnershipDepndtIs = othis.getView().byId("EMMODep").getValue();
			entity.OwnershipOtherIs = othis.getView().byId("EMMOOth").getValue();

			entity.LeasedorfreeholdIP = this.getView().byId("GroupA").getSelectedButton().getText();
			entity.RelationwithnmdcIp = this.getView().byId("GroupB").getSelectedButton().getText();
			entity.LeasedorfreeholdIs = this.getView().byId("GroupC").getSelectedButton().getText();
			entity.RelationwithnmdcIs = this.getView().byId("GroupD").getSelectedButton().getText();

			entity.MoaPsgmlIs = othis.getView().byId("magd").getValue();
			//entity.TentativePurIs = othis.getView().byId("propertgypr").getValue();
			//entity.SourceIs = othis.getView().byId("srcdoc").getValue();
			entity.RefNumDateIs = othis.getView().byId("refn").getValue();
			entity.PartyNameAddIs = othis.getView().byId("partyadd").getValue();
			entity.RelPartyEmpIs = othis.getView().byId("relationint").getValue();
			entity.DetailsDealerIs = this.getView().byId("detaild").getValue();
			entity.AnyOtherFactsIs = othis.getView().byId("declareem").getValue();

			entity.ApproverStatus = 'Submitted';

			var oModelDep = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);

			oModelDep.create('/Annual_PropertySet', entity, null, function() {
				othis.requestId = "";
				sap.m.MessageBox.success("Request Submitted successful.", {
					actions: [MessageBox.Action.OK],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function(sAction) {
						othis.onClear();
						othis.onBack();
						sap.ui.core.BusyIndicator.hide();
					}
				});
				sap.ui.core.BusyIndicator.hide();

			}, function() {
				sap.m.MessageBox.error("Error! Request Not Submitted.");
				sap.ui.core.BusyIndicator.hide();
			});

		},

		onClear: function(oEvent) {
			//	othis.getView().byId("priorRemarks1").setValue("");
			// othis.getView().byId("priorRemarks2").setValue("");
			//	othis.getView().byId("priorRemarks3").setValue("");
			// othis.getView().byId("priorRemarks4").setValue("");
			//		othis.getView().byId("priorRemarks5").setValue("");
			// othis.getView().byId("priorRemarks6").setValue("");
			othis.getView().byId("priorRemarks7").setValue("");
			// othis.getView().byId("priorRemarks8").setValue("");

			othis.getView().byId("FUBankIP").clear();
			othis.getView().byId("FULoanIP").clear();
			othis.getView().byId("FUAgrIP").clear();
			othis.getView().byId("FUEstIP").clear();
			othis.getView().byId("FULatPayIP").clear();
			othis.getView().byId("FUOthrDocIP").clear();

			othis.getView().byId("FUBankIS").clear();
			othis.getView().byId("FULoanIS").clear();
			othis.getView().byId("FUAgrIS").clear();
			othis.getView().byId("FUEstIS").clear();
			othis.getView().byId("FULatPayIS").clear();
			othis.getView().byId("FUOthrDocIS").clear();

			othis.getView().byId("pro").setValue("");
			othis.getView().byId("DP4").setValue("");
			othis.getView().byId("make").setValue("");
			othis.getView().byId("ref").setValue("");
			othis.getView().byId("party").setValue("");
			othis.getView().byId("relation").setValue("");
			othis.getView().byId("detail").setValue("");
			othis.getView().byId("declare").setValue("");

			othis.getView().byId("des").setValue("");
			othis.getView().byId("DP5").setValue("");
			othis.getView().byId("makem").setValue("");
			othis.getView().byId("refer").setValue("");
			othis.getView().byId("partyn").setValue("");
			othis.getView().byId("relations").setValue("");
			othis.getView().byId("det").setValue("");
			othis.getView().byId("dec").setValue("");

			othis.getView().byId("proper").setValue("");
			othis.getView().byId("DOYPsale").setValue("");
			othis.getView().byId("Coymp").setValue("");
			othis.getView().byId("EYMO").setValue("");

			othis.getView().byId("CoympSt").setValue("");
			othis.getView().byId("CoympDis").setValue("");
			othis.getView().byId("CoympPin").setValue("");
			othis.getView().byId("EYMODep").setValue("");
			othis.getView().byId("EYMOOth").setValue("");

			othis.getView().byId("matd").setValue("");
			othis.getView().byId("prertypr").setValue("");
			othis.getView().byId("refern").setValue("");
			othis.getView().byId("partyad").setValue("");
			othis.getView().byId("Pne").setValue("");
			othis.getView().byId("detailsd").setValue("");
			othis.getView().byId("declareemp").setValue("");

			othis.getView().byId("scapay").setValue("");
			othis.getView().byId("basisalary").setValue("");
			othis.getView().byId("desproIPS").setValue("");
			othis.getView().byId("Cogmp").setValue("");

			othis.getView().byId("CogmpSt").setValue("");
			othis.getView().byId("CogmpDis").setValue("");
			othis.getView().byId("CogmpPin").setValue("");
			othis.getView().byId("EMMODep").setValue("");
			othis.getView().byId("EMMOOth").setValue("");

			othis.getView().byId("EMGO").setValue("");
			othis.getView().byId("magd").setValue("");
			othis.getView().byId("propertgypr").setValue("");

			othis.getView().byId("refn").setValue("");
			othis.getView().byId("partyadd").setValue("");
			othis.getView().byId("relationint").setValue("");
			othis.getView().byId("detaild").setValue("");
			othis.getView().byId("declareem").setValue("");

			//manisha
			othis.getView().byId("SalSavPriorIP").setValue("");
			othis.getView().byId("BankComPriorIP").setValue("");
			othis.getView().byId("GoldOthrPriorIP").setValue("");
			othis.getView().byId("SellPriorIP").setValue("");
			othis.getView().byId("LoanRelPriorIP").setValue("");

			othis.getView().byId("BankCBIP").setSelected(false);
			othis.getView().byId("LoanCBIP").setSelected(false);
			othis.getView().byId("AgrCBIP").setSelected(false);
			othis.getView().byId("EstCBIP").setSelected(false);
			othis.getView().byId("LatPayCBIP").setSelected(false);
			othis.getView().byId("OthrDocCBIP").setSelected(false);

			othis.getView().byId("SalSavPriorIS").setValue("");
			othis.getView().byId("BankComPriorIS").setValue("");
			othis.getView().byId("GoldOthrPriorIS").setValue("");
			othis.getView().byId("SellPriorIS").setValue("");
			othis.getView().byId("LoanRelPriorIS").setValue("");

			othis.getView().byId("BankCBIS").setSelected(false);
			othis.getView().byId("LoanCBIS").setSelected(false);
			othis.getView().byId("AgrCBIS").setSelected(false);
			othis.getView().byId("EstCBIS").setSelected(false);
			othis.getView().byId("LatPayCBIS").setSelected(false);
			othis.getView().byId("OthrDocCBIS").setSelected(false);
			//end

			var oModelFileSet1 = new sap.ui.model.json.JSONModel();
			var oData1 = [];
			oData1.results = [];
			oModelFileSet1.setData(oData1);
			var that = this;
			that.getView().byId("UploadCollection").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection1").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection2").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection3").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection4").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection5").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection6").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection7").setModel(oModelFileSet1);

		},

		handleUploadComplete1: function(oEvent) {
			var sResponse = oEvent.getParameter("response"),
				aRegexResult = /\d{4}/.exec(sResponse),
				iHttpStatusCode = aRegexResult && parseInt(aRegexResult[0]),
				sMessage;

			if (sResponse) {
				sMessage = iHttpStatusCode === 200 ? sResponse + " (Upload Success)" : sResponse + " (Upload Error)";
				MessageToast.show(sMessage);
			}
		},

		/*	handleUploadPress: function() {
			var oFileUploader = this.byId("fileUploader");
			oFileUploader.checkFileReadable().then(function() {
				oFileUploader.upload();
			}, function(error) {
				MessageToast.show("The file cannot be read. It may have changed.");
			}).then(function() {
				oFileUploader.clear();
			});
		}*/

		onFileDeleted: function(oEvent) {
			this.deleteItemById(oEvent.getParameter("documentId"));
			MessageToast.show("FileDeleted event triggered.");
		},

		deleteItemById: function(sItemToDeleteId) {
			var oData = this.byId("UploadCollection").getModel().getData();
			var aItems = deepExtend({}, oData).items;
			jQuery.each(aItems, function(index) {
				if (aItems[index] && aItems[index].documentId === sItemToDeleteId) {
					aItems.splice(index, 1);
				}
			});
			this.byId("UploadCollection").getModel().setData({
				"items": aItems
			});
			this.byId("attachmentTitle").setText(this.getAttachmentTitleText());
		},

		// 	onChange: function(oEvent) {
		// 	var oUploadCollection = oEvent.getSource();
		// 	// Header Token
		// 	var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
		// 		name: "x-csrf-token",
		// 		value: "securityTokenFromModel"
		// 	});
		// 	oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		// },

		onBeforeUpload: function(oEvent) {
			fileName1_details = oEvent;
			return;
		},

		handleUploadPressBankIP: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUBankIP");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVPUR" + "|" + "BANK|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressLoanIP: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FULoanIP");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVPUR" + "|" + "LOAN|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressAgrIP: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUAgrIP");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVPUR" + "|" + "AGREEMENT|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressEstIP: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUEstIP");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVPUR" + "|" + "ESTIMATION|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressLatPayIP: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FULatPayIP");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVPUR" + "|" + "LATESTPAY|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressOthrDocIP: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUOthrDocIP");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVPUR" + "|" + "OTHERDOC|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleFileUploadPressIP: function(oEvent) {
			othis.handleUploadPressOthrDocIP();
			othis.handleUploadPressLatPayIP();
			othis.handleUploadPressEstIP();
			othis.handleUploadPressAgrIP();
			othis.handleUploadPressLoanIP();
			othis.handleUploadPressBankIP();
		},
		
		
		
		handleUploadPressBankIS: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUBankIS");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVSAL" + "|" + "BANK|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressLoanIS: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FULoanIS");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVSAL" + "|" + "LOAN|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
			FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
		// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressAgrIS: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUAgrIS");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVSAL" + "|" + "AGREEMENT|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
				FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
	
			// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressEstIS: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUEstIS");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVSAL" + "|" + "ESTIMATION|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
				FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
	
			// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressLatPayIS: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FULatPayIS");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVSAL" + "|" + "LATESTPAY|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
				FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
	
			// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},

		handleUploadPressOthrDocIS: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			var FUBankIP = this.getView().byId("FUOthrDocIS");

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;
			}

			var oModel = this.getView().getModel();
			oModel.refreshSecurityToken();
			var oHeaders = oModel.oHeaders;
			var sToken = oHeaders['x-csrf-token'];
			//			this.csrfToken = this.getView().getModel().getSecurityToken();
			FUBankIP.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(sToken);
			FUBankIP.addHeaderParameter(headerParma);

			var oCustomerHeaderSlug = new sap.ui.unified.FileUploaderParameter();
			oCustomerHeaderSlug.setName('slug');
			oCustomerHeaderSlug.setValue(FUBankIP.getValue() + "|" + "IMMOVSAL" + "|" + "OTHERDOC|" + userdId + "|" + this.requestId + "|" +
				pageInd);
			FUBankIP.addHeaderParameter(oCustomerHeaderSlug);
				FUBankIP.upload();
		FUBankIP.destroyHeaderParameters();
	
			// FUBankIP.checkFileReadable().then(function() {
			// 	FUBankIP.upload();
			// 	FUBankIP.destroyHeaderParameters();
			// }, function(error) {
			// 	sap.m.MessageToast.show("The file cannot be read. It may have changed.");
			// }).then(function() {
			// 	FUBankIP.clear();
			// });
		},
		
			handleFileUploadPressIS: function(oEvent) {
			othis.handleUploadPressOthrDocIS();
			othis.handleUploadPressLatPayIS();
			othis.handleUploadPressEstIS();
			othis.handleUploadPressAgrIS();
			othis.handleUploadPressLoanIS();
			othis.handleUploadPressBankIS();
		},

		onBeforeUploadStarts: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "MOVPUR" + "|" + "NONFIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

		onBeforeUploadStarts1: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "MOVPUR" + "|" + "FIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});

			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

		onBeforeUploadStarts2: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();

			if (this.requestId === "") {
				//	this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "MOVSAL" + "|" + "NONFIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
		onBeforeUploadStarts3: function(oEvent) {
			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "MOVSAL" + "|" + "FIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
		onBeforeUploadStarts4: function(oEvent) {

			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();

			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "IMMOVPUR" + "|" + "NONFIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

		onBeforeUploadStarts5: function(oEvent) {

			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "IMMOVPUR" + "|" + "FIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
		//start manisha
		onClickedMP: function(oEvent) {
			var bSelected = oEvent.getParameter("selected");
			this.getView().byId("BankCBMP").setSelected(bSelected);
			this.getView().byId("LoanCBMP").setSelected(bSelected);
			this.getView().byId("AgrCBMP").setSelected(bSelected);
			this.getView().byId("EstCBMP").setSelected(bSelected);
			this.getView().byId("LatPayCBMP").setSelected(bSelected);
			this.getView().byId("OthrDocCBMP").setSelected(bSelected);
		},

		onClickedMS: function(oEvent) {
			var bSelected = oEvent.getParameter("selected");
			this.getView().byId("BankCBMS").setSelected(bSelected);
			this.getView().byId("LoanCBMS").setSelected(bSelected);
			this.getView().byId("AgrCBMS").setSelected(bSelected);
			this.getView().byId("EstCBMS").setSelected(bSelected);
			this.getView().byId("LatPayCBMS").setSelected(bSelected);
			this.getView().byId("OthrDocCBMS").setSelected(bSelected);
		},

		onClickedIP: function(oEvent) {
			var bSelected = oEvent.getParameter("selected");
			this.getView().byId("BankCBIP").setSelected(bSelected);
			this.getView().byId("LoanCBIP").setSelected(bSelected);
			this.getView().byId("AgrCBIP").setSelected(bSelected);
			this.getView().byId("EstCBIP").setSelected(bSelected);
			this.getView().byId("LatPayCBIP").setSelected(bSelected);
			this.getView().byId("OthrDocCBIP").setSelected(bSelected);
		},

		onClickedIS: function(oEvent) {
			var bSelected = oEvent.getParameter("selected");
			this.getView().byId("BankCBIS").setSelected(bSelected);
			this.getView().byId("LoanCBIS").setSelected(bSelected);
			this.getView().byId("AgrCBIS").setSelected(bSelected);
			this.getView().byId("EstCBIS").setSelected(bSelected);
			this.getView().byId("LatPayCBIS").setSelected(bSelected);
			this.getView().byId("OthrDocCBIS").setSelected(bSelected);
		},
		//end manisha
		onBeforeUploadStarts6: function(oEvent) {

			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "IMMOVSAL" + "|" + "NONFIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

		onBeforeUploadStarts7: function(oEvent) {

			var userdId = oEmpData.Pernr;
			var pageInd = this.getView().byId("empname333").getValue();
			if (this.requestId === "") {
				this.requestId = dateFormat.format(new Date()) + oEmpData.Pernr;

			}

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName") + "|" + "IMMOVSAL" + "|" + "FIN|" + userdId + "|" + this.requestId + "|" + pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

		onUploadComplete: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection");
			var oData = oUploadCollection.getModel().getData();

			// flag for validation of movpur
			this.attachmentFlagMovPur1 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "MOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "MOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		},

		onUploadComplete1: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection1");
			var oData = oUploadCollection.getModel().getData();

			this.attachmentFlagMovPur2 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "MOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "MOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		},
		onUploadComplete2: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection2");
			var oData = oUploadCollection.getModel().getData();

			// flag for validation of immovpur
			this.attachmentFlagMovSal1 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "MOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "MOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		},
		onUploadComplete3: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection3");
			var oData = oUploadCollection.getModel().getData();

			this.attachmentFlagMovSal2 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "MOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "MOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		},
		onUploadComplete4: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection4");
			var oData = oUploadCollection.getModel().getData();

			this.attachmentFlagImmovPur1 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "IMMOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "IMMOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		},
		onUploadComplete5: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection5");
			var oData = oUploadCollection.getModel().getData();

			this.attachmentFlagImmovPur2 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "IMMOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "IMMOVPUR",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		},
		onUploadComplete6: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection6");
			var oData = oUploadCollection.getModel().getData();

			// flag for validation of immovsal
			this.attachmentFlagImmovSal1 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "IMMOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "NONFIN",
					"TabInd": "IMMOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		},
		onUploadComplete7: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection7");
			var oData = oUploadCollection.getModel().getData();

			this.attachmentFlagImmovSal2 = true;

			if (oData !== null) {
				oData.results.unshift({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "IMMOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			} else {
				oData = [];
				oData.results = [];
				oData.results.push({
					"FileName": oEvent.getParameter("files")[0].fileName,
					"Indicator": "FIN",
					"TabInd": "IMMOVSAL",
					"UserId": "",
					"RequestId": "",
					"PageIndicator": "Priorview"
				});
			}
			oUploadCollection.getModel().refresh();
		}

	});

});