sap.ui.define([
	'jquery.sap.global',
	"sap/ui/core/mvc/Controller", 	"sap/ui/core/format/DateFormat","sap/ui/core/library",'sap/m/MessageBox', "sap/ui/model/Filter","sap/ui/model/Sorter", 'sap/m/MessageToast', './Formatter'
], function(jQuery, Controller,DateFormat,CoreLibrary, Filter,Sorter, othis, MessageBox, oEmpData, oDep, Formatter, oDataSelected, oModelEmpLoan, oPCTData,
	MessageToast) {
	"use strict";
	var SortOrder = CoreLibrary.SortOrder;

	return Controller.extend("annualpropertyannualproperty.controller.View1", {
		onInit: function() {
			this.onRead();
			othis = this;
			sap.ui.core.BusyIndicator.show(0);
			var oModelLoan = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			this.getView().setModel(oModelLoan);
		//	var oParameter = 'UserId';
		//var opernr = sap.ushell.Container.getService("UserInfo").getId() 
			var opernr = oEmpData.Pernr;
			Filter = new sap.ui.model.Filter('UserId', 'EQ', opernr);
			 oModelLoan.read("/Annual_PropertySet?$top=5", {
				filters: [Filter],
				success: function(oData, oResponse) {
					oModelEmpLoan = new sap.ui.model.json.JSONModel();
					debugger;
				if(oData.results !== undefined){
					for(var i=0;i<oData.results.length;i++){
						
						if(oData.results[i].Approver2Status !== ""){
						if( oData.results[i].Approver2Status === "Rejected"){
								oData.results[i].customStatus = "Rejected" ;
							}else{
								oData.results[i].customStatus =  oData.results[i].Approver2Status === "Submitted" ? "Pending with Approver 2" : oData.results[i].Approver2Status ;
						}
						}else if(oData.results[i].ApproverStatus !== ""){
							if( oData.results[i].ApproverStatus === "Rejected"){
								oData.results[i].customStatus = "Rejected by Approver 1" ;
							}else{
								oData.results[i].customStatus = oData.results[i].ApproverStatus === "Submitted" ? "Pending with Approver 1"  :"Approved by Approver 1" ;
								
							}
			//					oData.results[i].customStatus = oData.results[i].ApproverStatus === "Submitted" ? "Pending with Approver 1"  : oData.results[i].ApproverStatus ;
						}else{
							oData.results[i].customStatus = "Submitted";
						}
						
					
					}
				}
					
					oModelEmpLoan.setData(oData);
					//oModelEmpLoan.sap.ui.model.Model.setSizeLimit(3);
					othis.getView().setModel(oModelEmpLoan, "oModelLoans");
					//	othis.onTableSort();
					
					//manisha
						//Initial sorting
			// var oProductNameColumn = othis.getView().byId("deliverydate");
			// othis.getView().byId("reqs").sort(oProductNameColumn, SortOrder.Descending);
					//end
					sap.ui.core.BusyIndicator.hide();

				},
				error: function(error) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageBox.error("Error in fetching data, Please refresh and try again.");
					return;
				}
			});
			// var oUploadCollection = this.getView().byId('UploadCollection');
			//  oUploadCollection.setUploadUrl("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/FileSet");
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV", false);
			this.getView().setModel(oModel);

		},

		onTableSort: function() {
			var table = this.getView().byId("reqs");

			var oItems = table.getBinding("items");

			var oBindingPath = table.getModel().getProperty("/results");

			var oSorter = new sap.ui.model.Sorter(oBindingPath);

			oItems.sort(oSorter);

		},
		
		// 	sortDeliveryDate: function(oEvent) {
		// 	var oCurrentColumn = oEvent.getParameter("column");
		// 	var oDeliveryDateColumn = this.byId("deliverydate");
		// 	if (oCurrentColumn != oDeliveryDateColumn) {
		// 		oDeliveryDateColumn.setSortOrder(SortOrder.None); //No multi-column sorting
		// 		return;
		// 	}

		// 	oEvent.preventDefault();

		// 	var sOrder = "Ascending" ; //oEvent.getParameter("sortOrder");
		// 	var oDateFormat = DateFormat.getDateInstance({pattern: "dd/MM/yyyy"});

		// 	this._resetSortingState(); //No multi-column sorting
		
		// 	oDeliveryDateColumn.setSortOrder(sOrder);

		// 	var oSorter = new sap.ui.model.Sorter(oDeliveryDateColumn.getSortProperty(), sOrder === SortOrder.Ascending);
		// 	//The date data in the JSON model is string based. For a proper sorting the compare function needs to be customized.
		//  oSorter.fnCompare = function(a, b) {
                
  //                  // parse to Date object
  //                  var aDate = new Date(a);
  //                  var bDate = new Date(b);
                    
  //                  if (bDate === null) {
  //                      return -1;
  //                  }
  //                  if (aDate === null) {
  //                      return 1;
  //                  }
  //                  if (aDate < bDate) {
  //                      return -1;
  //                  }
  //                  if (aDate > bDate) {
  //                      return 1;
  //                  }
  //                  return 0;
  //              };
            
		// 	var oTable = this.getView().byId("table");
		// //	this.getView().byId("table").getBinding().sort(oSorter);
		// 	 oTable.getBinding('rows').sort(oSorter);
  //          // prevent internal sorting by table
  //         oEvent.preventDefault();
		// },
		
		// 	_resetSortingState: function() {
		// 	var oTable = this.getView().byId("table");
		// 	var aColumns = oTable.getColumns();
		// 	for (var i = 0; i < aColumns.length; i++) {
		// 		aColumns[i].setSortOrder(SortOrder.None);
		// 	}
		// },
		
		
			displayTable: function() {
			// var leaveSince = this.getView().byId("DP1").getValue();
			// var filter = new sap.ui.model.Filter("CREATION_DATE", sap.ui.model.FilterOperator.EQ, leaveSince);
			// var list = this.getView().byId("reqs");
			// var binding = list.getBinding("items");
			// binding.filter([filter]);
				// add filter for search
				
					debugger;
			var aFilters = [];
			var sQuery = this.getView().byId("DP1").getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new sap.ui.model.Filter("Zdate", sap.ui.model.FilterOperator.EQ, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = this.byId("reqs");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},
		sortDeliveryDate: function(oEvent) {
			debugger;
			var oCurrentColumn = oEvent.getParameter("column");
			var oDeliveryDateColumn = this.byId("qwe");
			if (oCurrentColumn !== oDeliveryDateColumn) {
				oDeliveryDateColumn.setSorted(false); //No multi-column sorting
				return;
			}

			oEvent.preventDefault();

			var sOrder = oEvent.getParameter("sortOrder");
			var oDateFormat = DateFormat.getDateInstance({
				pattern: "dd-mm-yyyy"
			});

			this._resetSortingState(); //No multi-column sorting
			oDeliveryDateColumn.setSorted(true);
			oDeliveryDateColumn.setSortOrder(sOrder);

			var oSorter = new Sorter(oDeliveryDateColumn.getSortProperty(), sOrder === SortOrder.Descending);
			//The date data in the JSON model is string based. For a proper sorting the compare function needs to be customized.
			oSorter.fnCompare = function(a, b) {
				if (b == null) {
					return -1;
				}
				if (a == null) {
					return 1;
				}

				var aa = oDateFormat.parse(a).getTime();
				var bb = oDateFormat.parse(b).getTime();

				if (aa < bb) {
					return -1;
				}
				if (aa > bb) {
					return 1;
				}
				return 0;
			};

			this.byId("reqs").getBinding().sort(oSorter);
		},



		onRead: function() {
			othis = this;
				debugger;
			sap.ui.core.BusyIndicator.show(0);
			var oModelEmp = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			this.getView().setModel(oModelEmp);
			oModelEmp.read("/Annual_PropertySet(UserId='DUMMY')", {
				async:false,
				success: function(oData, oResponse) {
					var oModelEmpData = new sap.ui.model.json.JSONModel();
					oModelEmpData.setData(oData);
					oEmpData = oData;
					othis.getView().setModel(oModelEmpData, "oModelEmployee");
					Filter = new sap.ui.model.Filter('UserId', 'EQ', oData.EmployeeNumber);
					var oModelDep = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
					oModelDep.read("/Annual_PropertySet", {
						filters: [Filter],
						async:false,	success: function(oDataDep, oResponseDep) {
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData(oDataDep);
							oDep = oDataDep.results;
							othis.getView().setModel(oModel, "oModelDep");
						},
						error: function(error) {
							sap.ui.core.BusyIndicator.hide();
							sap.m.MessageBox.error("User Id is not assigned to Valid Employee ID.");
						}
					});
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(err) {
					sap.m.MessageBox.error("User Id is not assigned to Valid Employee ID.");
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},

		//var oModel1 = sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
		//	this.getView().setModel(oModelEmp, "Annual_PropertySet");
		/*	onReadTableData: function() {
			   var othis = this;
				var oModelEmp = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
				this.getView().setModel(oModelEmp);
				Filter = new sap.ui.model.Filter('UserId', 'EQ', oData.EmployeeNumber);
				oModelEmp.read("/Annual_PropertySet?$top=5", {
					filters: [Filter],
					success: function(oData, oResponse) {
						var oModMed = new sap.ui.model.json.JSONModel();
						oModMed.setData(oData);
						othis.getView().setModel(oModMed, "oModMedLet");
						sap.ui.core.BusyIndicator.hide();
					},
					error: function(error) {
						sap.m.MessageBox.error("User ID is not assigned to Valid Employee");
						sap.ui.core.BusyIndicator.hide();
					}
				});
			
		},*/

		onReadTableData: function() {
			var othis = this;
			var oModelEmp = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			this.getView().setModel(oModelEmp);
			Filter = new sap.ui.model.Filter('UserId', 'EQ', oData.EmployeeNumber);
			oModelEmp.read("/Annual_PropertySet?$top=5", {
				//oModelEmp.read("/Annual_PropertySet", {
				filters: [Filter],
				success: function(oData, oResponse) {
					var oModMed = new sap.ui.model.json.JSONModel();
					oModMed.setData(oData);
					othis.getView().setModel(oModMed, "oModelEmp");
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(error) {
					sap.m.MessageBox.error("User ID is not assigned to Valid Employee");
					sap.ui.core.BusyIndicator.hide();
				}
			});

			
		},

		onDownload1: function(oEvent) {

			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("oModelLoans");
			var sPath = oContext.getPath();
			var oModel = oContext.getModel();
			oDataSelected = oModel.getProperty(sPath);

			if (oDataSelected) {
				var oUri = "/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/GenerateOrderCopySet(Key='" + oDataSelected.Pernr + "|" + oDataSelected.RefNumber +
					"|" + oDataSelected.Status + "')/$value";
				sap.m.URLHelper.redirect(oUri, true);
			}
		},

		onDownload: function(oEvent) {

			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("oModelLoans");
			var sPath = oContext.getPath();
			var oModel = oContext.getModel();
			oDataSelected = oModel.getProperty(sPath);

			if (oDataSelected) {
				var oUri = "/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/GenerateLetterSet(Key='" + oDataSelected.Pernr + "|" + oDataSelected.RefNumber +
					"|" + oDataSelected.Status + "')/$value";
				sap.m.URLHelper.redirect(oUri, true);
			}
		},

		/*	onListItemPress: function(oEvent) {
			var oSelectedItem = oEvent.getSource();
			var oContext = oSelectedItem.getBindingContext("oModelReq");
			var sPath = oContext.getPath();
			var oModel = oContext.getModel();
			oDataSelected = oModel.getProperty(sPath);
			if (oDataSelected) {
				this.getView().byId("refno").setValue(oDataSelected.ReferenceNo);
				this.getView().byId("emp").setValue(oDataSelected.EmployeeID);
				this.getView().byId("reqfor").setValue(oDataSelected.RelationName);
				this.getView().byId("name").setValue(oDataSelected.AppliedFor);
				this.getView().byId("age").setValue(oDataSelected.Age);
				this.getView().byId("gender").setValue(oDataSelected.Gender);
				this.getView().byId("aadharno").setValue(oDataSelected.Aadharno);
				this.getView().byId("loc").setValue(oDataSelected.HospitalLoc);
				this.getView().byId("hosp").setValue(oDataSelected.HospitalName);
				this.getView().byId("hospname").setValue(oDataSelected.HospitalName);
				this.getView().byId("state").setValue(oDataSelected.STATE);
				this.getView().byId("city").setValue(oDataSelected.HospitalLoc);
				this.getView().byId("pincode").setValue(oDataSelected.PINCODE);
				this.getView().byId("pack").setValue(oDataSelected.Package);
				this.getView().byId("package").setValue(oDataSelected.Package);
				this.getView().byId("history").setValue(oDataSelected.MedicalHistory);
				this.getView().byId("status").setValue(oDataSelected.Status);
				this.getView().byId("form").setVisible(true);
				this.getView().byId("details").setVisible(true);
				this.getView().byId("approve").setEnabled(true);
				this.getView().byId("reject").setEnabled(true);
				this._onReadEmpDetails(oDataSelected);
			}
		},*/

		// 	onSelectionChange: function(oEvent) {
		// 	var sOrderId = oEvent.getSource().getSelectedItem().getBindingContext().getProperty("RefNumber");
		// 	this.getOwnerComponent().getRouter()
		// 		.navTo("Priorview");
		// 		//	{orderId:sOrderId});
		// },

		onAdd: function(oEvent) {
			var oButton = oEvent.getSource();
			this.byId("actionSheet").openBy(oButton);
		},
		onFilterClick: function() {
			this.dialogs = sap.ui.xmlfragment("annualpropertyannualproperty.Fragments.filter", this);
			this.dialogs.open();
		},
		onNew: function() {
			this.dialogs = sap.ui.xmlfragment("annualpropertyannualproperty.Fragments.newbutton", this);
			this.dialogs.open();
		},
		onConfirmDetails: function(oEvent) {
			var value = oEvent.getParameter("selectedItem").getTitle();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			if (value === "Prior Approval") {
				oRouter.navTo("Priorview");

			} else if (value === "Final Approval") {
				//oRouter.navTo("postview");
				oRouter.navTo("PriorListView", {EmpId: window.encodeURIComponent( oEmpData.Pernr)});	
			} else if (value === "Movable Approval") {
				oRouter.navTo("MovPur");	
			} else if (value === "Movable Sales") {
				oRouter.navTo("MovSal");	
			}
		},
		onPre: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("preapprove");

		},

		// 	onConfirmDetails:function(oEvent){
		// 	var value = oEvent.getParameter("selectedItem").getTitle(); 
		// 	if(value === "Post Approval"){
		// 		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		//   oRouter.navTo("postview");
		// 	}

		// }

		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		handleUploadComplete: function(oEvent) {
			var sResponse = oEvent.getParameter("response");
			if (sResponse) {
				var sMsg = "";
				var m = /^\[(\d\d\d)\]:(.*)$/.exec(sResponse);
				if (m[1] == "200") {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Success)";
					oEvent.getSource().setValue("");
				} else {
					sMsg = "Return Code: " + m[1] + "\n" + m[2] + "(Upload Error)";
				}

				MessageToast.show(sMsg);
			}
		},

		handleUploadPress: function(oEvent) {
			var oFileUploader = this.byId("fileUploader");
			if (!oFileUploader.getValue()) {
				MessageToast.show("Choose a file first");
				return;
			}
			oFileUploader.upload();
		},

		handleTypeMissmatch: function(oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			jQuery.each(aFileTypes, function(key, value) {
				aFileTypes[key] = "*." + value;
			});
			var sSupportedFileTypes = aFileTypes.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				sSupportedFileTypes);
		},

		handleValueChange: function(oEvent) {
			MessageToast.show("Press 'Upload File' to upload file '" +
				oEvent.getParameter("newValue") + "'");
		},
		/////////////////////////////////////////////////////////////////
		onBeforeUploadStarts: function(oEvent) {

			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
		onUploadComplete: function(oEvent) {
			this.getView().getModel().refresh();
		},

	});
});