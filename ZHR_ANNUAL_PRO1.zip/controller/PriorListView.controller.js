sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/base/util/deepExtend",
	"sap/ui/model/Filter",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast"
], function(Controller, othis, MessageBox, deepExtend, Filter, oEmpData, oDep, Formatter,dateFormat, oDataSelected,fileName1_details, oPCTData, MessageToast) {
	"use strict";

	return Controller.extend("annualpropertyannualproperty.controller.PriorListView", {
		onBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
		},
		
		onObjectMatched : function(oEvent){
			othis =this;
			var oModelLoan = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			this.getView().setModel(oModelLoan);
			var oModelEmpLoan = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
		//	var oParameter = 'UserId';
		//var opernr = sap.ushell.Container.getService("UserInfo").getId() 
			var opernr = window.decodeURIComponent(oEvent.getParameter("arguments").EmpId);
			Filter = new sap.ui.model.Filter('UserId', 'EQ', opernr);
		var	Filter1 = new sap.ui.model.Filter('ApproverStatus', 'EQ', 'Approved');
		var	Filter2 = new sap.ui.model.Filter('Approver2Status', 'EQ', '');
		var	Filter3 = new sap.ui.model.Filter('TabInd', 'EQ', 'IMMOVPUR');
		
		
		
		
				// var	Filter2= new sap.ui.model.Filter({
				// filters: [new sap.ui.model.Filter('ApproverStatus', 'EQ', 'Approved'),
				// 		  new sap.ui.model.Filter('Approver2Status', 'EQ', '')
				// ],
				// and: true
				// });
				
			 oModelLoan.read("/Annual_PropertySet?$top=5", {
				filters: [Filter,Filter1,Filter2,Filter3],
				success: function(oData, oResponse) {
					oModelEmpLoan = new sap.ui.model.json.JSONModel();
					oModelEmpLoan.setData(oData);
					othis.getView().setModel(oModelEmpLoan, "oModelLoans");
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(error) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageBox.error("Error in fetching data, Please refresh and try again.");
					return;
				}
			});
		
		},

		onInit: function() {
			
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("PriorListView").attachPatternMatched(this.onObjectMatched, this);
			
		},
		
		onListItemPress: function(oEvent) {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PriorViewApproved", {ReqNum: window.encodeURIComponent(oEvent.getSource().getTitle())});
		
		},
		
		oncreatenewpost: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("postview");
		}

	

	});

});