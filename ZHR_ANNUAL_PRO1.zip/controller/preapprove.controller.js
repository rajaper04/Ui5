sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast"
], function(Controller, othis, MessageBox, Filter, oEmpData, oDep, Formatter, dateFormat,oDataSelected, oPCTData) {
	"use strict";

	return Controller.extend("annualpropertyannualproperty.controller.preapprove", {
			onBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");
		},

			onInit: function() {
		
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV", false);
			this.getView().setModel(oModel);
			this.requestId = "";
			this.onRead();
		
			dateFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern : "yyyyMMddHHmmss" });   
		
			// flag for validation of movpur
			this.attachmentFlagMovPur1 =false;
			this.attachmentFlagMovPur2 =false;
			// flag for validation of immovpur
			this.attachmentFlagMovSal1 =false;
			this.attachmentFlagMovSal2 =false;
			// flag for validation of movsal
			this.attachmentFlagImmovPur1 =false;
			this.attachmentFlagImmovPur2 =false;
			// flag for validation of immovsal
			this.attachmentFlagImmovSal1 =false;
			this.attachmentFlagImmovSal2 =false;
			},
			
			
	onRead: function() {
			othis = this;
			sap.ui.core.BusyIndicator.show(0);
			var oModelEmp = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			this.getView().setModel(oModelEmp);
			oModelEmp.read("/Annual_PropertySet(UserId='DUMMY')", {
				success: function(oData, oResponse) {
					var oModelEmpData = new sap.ui.model.json.JSONModel();
					oModelEmpData.setData(oData);
					oEmpData = oData;
					othis.getView().setModel(oModelEmpData, "oModelEmployee");
					Filter = new sap.ui.model.Filter('UserId', 'EQ', oData.EmployeeNumber);
					var oModelDep = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
					oModelDep.read("/Annual_PropertySet", {
						filters: [Filter],
						success: function(oDataDep, oResponseDep) {
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData(oDataDep);
							oDep = oDataDep.results;
							othis.getView().setModel(oModel, "oModelDep");
						},
						error: function(error) {
							sap.ui.core.BusyIndicator.hide();
							MessageBox.error("User Id is not assigned to Valid Employee ID.");
						}
					});
					sap.ui.core.BusyIndicator.hide();
				},
				error: function(err) {
					MessageBox.error("User Id is not assigned to Valid Employee ID.");
					sap.ui.core.BusyIndicator.hide();
				}
			});
			
			
				//FileSet data
						var oModelFileSet = new sap.ui.model.json.JSONModel();
				var	oData=[];
				oData.results=[];
				oModelFileSet.setData(oData);
					var that=this;
					that.getView().byId("UploadCollectionPreAp").setModel(oModelFileSet);
					that.getView().byId("UploadCollection13").setModel(oModelFileSet);
					that.getView().byId("UploadCollection23").setModel(oModelFileSet);
					that.getView().byId("UploadCollection33").setModel(oModelFileSet);
					that.getView().byId("UploadCollection43").setModel(oModelFileSet);
					that.getView().byId("UploadCollection53").setModel(oModelFileSet);
					that.getView().byId("UploadCollection63").setModel(oModelFileSet);
					that.getView().byId("UploadCollection73").setModel(oModelFileSet);


			// var oModelFileSet = new sap.ui.model.json.JSONModel();
			// var that = this;
			// oModelEmp.read("/FileSet", {
			// 	success: function(oData, oResponse) {
			// 		oModelFileSet.setData(oData);
			// 		that.getView().byId("UploadCollectionPreAp").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection13").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection23").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection33").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection43").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection53").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection63").setModel(oModelFileSet);
			// 		that.getView().byId("UploadCollection73").setModel(oModelFileSet);
			// 		sap.ui.core.BusyIndicator.hide();
			// 	},
			// 	error: function(err) {
			// 		MessageBox.error("Error while fetching fileset data.");
			// 		sap.ui.core.BusyIndicator.hide();
			// 	}
			// });

				
		},
			onsubmit: function(){
			var entity = {};
			 othis = this;
		//	debugger;
		//	Movable purchase set;
		
		if(this.requestId === ""){
			//	this.requestId = crypto.randomUUID();
		//	 this.requestId = Math.floor(Math.random() * 9000000000) + 1000000000; //10 digit random unique id
		 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
			entity.Pernr = oEmpData.Pernr;
			entity.PageIndicator = othis.getView().byId("empname333_preapprove").getValue();
			entity.RefNumber = this.requestId.toString();
				//	debugger;
			var IconTabBarIdKey=othis.getView().byId("PreappIconTabBarId").getSelectedKey();
		//	entity.PropertyType=IconTabBarIdKey;
			entity.TabInd=IconTabBarIdKey;
		//	entity.Zindicator=othis.finFlag;
		
		if(IconTabBarIdKey === "MOVPUR"){
		if(this.attachmentFlagMovPur1 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		
		if(this.attachmentFlagMovPur2 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		}
		
		if(IconTabBarIdKey === "MOVSAL"){
		if(this.attachmentFlagMovSal1 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		
		if(this.attachmentFlagMovSal2 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		}
	
		if(IconTabBarIdKey === "IMMOVSAL"){
		if(this.attachmentFlagImmovSal1 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		
		if(this.attachmentFlagImmovSal2 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		}
	
		if(IconTabBarIdKey === "IMMOVPUR"){
		if(this.attachmentFlagImmovPur1 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		
		if(this.attachmentFlagImmovPur2 === false){
			sap.m.MessageBox.error("Attachment is mandatory.");
			return;
		}
		}
	
			entity.ZPRE1TEXT1 = othis.getView().byId("preappRemarks1").getValue();
			entity.ZPRE1TEXT2 = othis.getView().byId("preappRemarks2").getValue();
			entity.ZPRE2TEXT1 = othis.getView().byId("preappRemarks3").getValue();
			entity.ZPRE2TEXT2 = othis.getView().byId("preappRemarks4").getValue();
			entity.ZPRE3TEXT1 = othis.getView().byId("preappRemarks5").getValue();
			entity.ZPRE3TEXT2 = othis.getView().byId("preappRemarks6").getValue();
			entity.ZPRE4TEXT1 = othis.getView().byId("preappRemarks7").getValue();
			entity.ZPRE4TEXT2 = othis.getView().byId("preappRemarks8").getValue();
		
			entity.PropertyDescriMp = othis.getView().byId("pro_MP_PRE").getValue();
			entity.MakeModelMp = othis.getView().byId("make_MP_PRE").getValue();
			entity.TentativeDateMp = this.getView().byId("DOP_MP_PRE").getValue();
			entity.PurchasePriceMp = othis.getView().byId("property_MP_PRE").getValue();
			entity.SourceMp = othis.getView().byId("src_MP_PRE").getValue();
			entity.RefNumDateMp = othis.getView().byId("ref_MP_PRE").getValue();
			entity.PartyNameAddMp = othis.getView().byId("party_MP_PRE").getValue();
			entity.RelPartyEmpMp = othis.getView().byId("relation_MP_PRE").getValue();
			entity.DetailsDealerMp = this.getView().byId("detail_MP_PRE").getValue();
			entity.AnyOtherFactsMp = othis.getView().byId("declare_MP_PRE").getValue();
			//	Movable Sales set;
			entity.PropertyDescriMs = othis.getView().byId("des_MS_PRE").getValue();
			entity.MakeModelMs = othis.getView().byId("makem_MS_PRE").getValue();
			entity.TentativeDateMs = this.getView().byId("DOPs_MS_PRE").getValue();
			entity.PurchasePriceMs = othis.getView().byId("price_MS_PRE").getValue();
			entity.SourceMs = othis.getView().byId("srcs_MS_PRE").getValue();
			entity.RefNumDateMs = othis.getView().byId("refer_MS_PRE").getValue();
			entity.PartyNameAddMs = othis.getView().byId("partyn_MS_PRE").getValue();
			entity.RelPartyEmpMs = othis.getView().byId("relations_MS_PRE").getValue();
			entity.DetailsDealerMs = this.getView().byId("det_MS_PRE").getValue();
			entity.AnyOtherFactsMs = othis.getView().byId("dec_MS_PRE").getValue();
		//	Immovable purchase set;		
			entity.PropertyDescriIp = othis.getView().byId("proper_IP_PRE").getValue();
			entity.TentativeDateIp = this.getView().byId("DOPP_IP_PRE").getValue();
			entity.CompleteAddrIp = othis.getView().byId("MOA_IP_PRE").getValue();
			entity.OwnershipPerIp = othis.getView().byId("own_IP_PRE").getValue();
			entity.MoaPsgmlIp = othis.getView().byId("makemo_IP_PRE").getValue();
			entity.TentativePurIp = othis.getView().byId("pproperty_IP_PRE").getValue();
			entity.SourceIp = othis.getView().byId("srce_IP_PRE").getValue();
			entity.RefNumDateIp = othis.getView().byId("refern_IP_PRE").getValue();
			entity.PartyNameAddIp = othis.getView().byId("partyad_IP_PRE").getValue();
			entity.RelPartyEmpIp = othis.getView().byId("Pne_IP_PRE").getValue();
			entity.DetailsDealerIp = this.getView().byId("detailsd_IP_PRE").getValue();
			entity.AnyOtherFactsIp = othis.getView().byId("declareemp_IP_PRE").getValue();
		//	Immovable sales set;	
			entity.PropertyDescriIs = othis.getView().byId("despro_IS_PRE").getValue();
			entity.TentativeDateIs = this.getView().byId("DOPsale_IS_PRE").getValue();
			entity.CompleteAddrIs = othis.getView().byId("Comp_IS_PRE").getValue();
			entity.OwnershipPerIs = othis.getView().byId("EMO_IS_PRE").getValue();
			entity.MoaPsgmlIs = othis.getView().byId("mad_IS_PRE").getValue();
			entity.TentativePurIs = othis.getView().byId("propertypr_IS_PRE").getValue();
			entity.SourceIs = othis.getView().byId("srcdoc_IS_PRE").getValue();
			entity.RefNumDateIs = othis.getView().byId("refn_IS_PRE").getValue();
			entity.PartyNameAddIs = othis.getView().byId("partyadd_IS_PRE").getValue();
			entity.RelPartyEmpIs = othis.getView().byId("relationint_IS_PRE").getValue();
			entity.DetailsDealerIs = this.getView().byId("detaild_IS_PRE").getValue();
			entity.AnyOtherFactsIs = othis.getView().byId("declareem_IS_PRE").getValue();
		
			
			var oModelDep = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZHR_ANNUAL_PROPERTY_SRV/", true);
			
				oModelDep.create('/Annual_PropertySet', entity, null, function() {
					othis.requestId = "";
			//	sap.m.MessageBox.success("Request Submitted successful.");
				sap.ui.core.BusyIndicator.hide();
				sap.m.MessageBox.success("Request Submitted successful.", {
				actions: [MessageBox.Action.OK],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function (sAction) {
				othis.onClear();
				othis.onBack();
				sap.ui.core.BusyIndicator.hide();
				}
			});
			}, function() {
				sap.m.MessageBox.error("Error! Request Not Submitted.");
				sap.ui.core.BusyIndicator.hide();
			});
				
		},
		
		onClear: function(oEvent) {
			othis.getView().byId("preappRemarks1").setValue("");
			othis.getView().byId("preappRemarks2").setValue("");
			othis.getView().byId("preappRemarks3").setValue("");
			othis.getView().byId("preappRemarks4").setValue("");
			othis.getView().byId("preappRemarks5").setValue("");
			othis.getView().byId("preappRemarks6").setValue("");
			othis.getView().byId("preappRemarks7").setValue("");
			othis.getView().byId("preappRemarks8").setValue("");
			
			
			othis.getView().byId("pro_MP_PRE").setValue("");
			othis.getView().byId("DOP_MP_PRE").setValue("");
			othis.getView().byId("make_MP_PRE").setValue("");
			othis.getView().byId("property_MP_PRE").setValue("");
			othis.getView().byId("src_MP_PRE").setValue("");
			othis.getView().byId("ref_MP_PRE").setValue("");
			othis.getView().byId("party_MP_PRE").setValue("");
			othis.getView().byId("relation_MP_PRE").setValue("");
			othis.getView().byId("detail_MP_PRE").setValue("");
			othis.getView().byId("declare_MP_PRE").setValue("");
		
			othis.getView().byId("des_MS_PRE").setValue("");
			othis.getView().byId("DOPs_MS_PRE").setValue("");
			othis.getView().byId("makem_MS_PRE").setValue("");
			othis.getView().byId("price_MS_PRE").setValue("");
			othis.getView().byId("srcs_MS_PRE").setValue("");
			othis.getView().byId("refer_MS_PRE").setValue("");
			othis.getView().byId("partyn_MS_PRE").setValue("");
			othis.getView().byId("relations_MS_PRE").setValue("");
			othis.getView().byId("det_MS_PRE").setValue("");
			othis.getView().byId("dec_MS_PRE").setValue("");
		
			othis.getView().byId("proper_IP_PRE").setValue("");
			othis.getView().byId("DOPP_IP_PRE").setValue("");
			othis.getView().byId("MOA_IP_PRE").setValue("");
			othis.getView().byId("own_IP_PRE").setValue("");
			othis.getView().byId("makemo_IP_PRE").setValue("");
			othis.getView().byId("pproperty_IP_PRE").setValue("");
			othis.getView().byId("srce_IP_PRE").setValue("");
			othis.getView().byId("refern_IP_PRE").setValue("");
			othis.getView().byId("partyad_IP_PRE").setValue("");
			othis.getView().byId("Pne_IP_PRE").setValue("");
			othis.getView().byId("detailsd_IP_PRE").setValue("");
			othis.getView().byId("declareemp_IP_PRE").setValue("");
			othis.getView().byId("prertypr").setValue("");
		
			othis.getView().byId("despro_IS_PRE").setValue("");
			othis.getView().byId("DOPsale_IS_PRE").setValue("");
			othis.getView().byId("Comp_IS_PRE").setValue("");
			othis.getView().byId("EMO_IS_PRE").setValue("");
			othis.getView().byId("mad_IS_PRE").setValue("");
			othis.getView().byId("propertypr_IS_PRE").setValue("");
		
			othis.getView().byId("srcdoc_IS_PRE").setValue("");
			othis.getView().byId("refn_IS_PRE").setValue("");
			othis.getView().byId("partyadd_IS_PRE").setValue("");
			othis.getView().byId("relationint_IS_PRE").setValue("");
			othis.getView().byId("detaild_IS_PRE").setValue("");
			othis.getView().byId("declareem_IS_PRE").setValue("");
			
			var oModelFileSet1 = new sap.ui.model.json.JSONModel();
			var oData1 = [];
			oData1.results = [];
			oModelFileSet1.setData(oData1);
			var that = this;
			that.getView().byId("UploadCollectionPreAp").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection13").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection23").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection33").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection43").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection53").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection63").setModel(oModelFileSet1);
			that.getView().byId("UploadCollection73").setModel(oModelFileSet1);

		},

		
				handleUploadComplete: function(oEvent) {
			var sResponse = oEvent.getParameter("response"),
				aRegexResult = /\d{4}/.exec(sResponse),
				iHttpStatusCode = aRegexResult && parseInt(aRegexResult[0]),
				sMessage;

			if (sResponse) {
				sMessage = iHttpStatusCode === 200 ? sResponse + " (Upload Success)" : sResponse + " (Upload Error)";
				MessageToast.show(sMessage);
			}
		},

		/*	handleUploadPress: function() {
			var oFileUploader = this.byId("fileUploader");
			oFileUploader.checkFileReadable().then(function() {
				oFileUploader.upload();
			}, function(error) {
				MessageToast.show("The file cannot be read. It may have changed.");
			}).then(function() {
				oFileUploader.clear();
			});
		}*/

		onFileDeleted: function(oEvent) {
			this.deleteItemById(oEvent.getParameter("documentId"));
			MessageToast.show("FileDeleted event triggered.");
		},

		deleteItemById: function(sItemToDeleteId) {
			var oData = this.byId("UploadCollection").getModel().getData();
			var aItems = deepExtend({}, oData).items;
			jQuery.each(aItems, function(index) {
				if (aItems[index] && aItems[index].documentId === sItemToDeleteId) {
					aItems.splice(index, 1);
				}
			});
			this.byId("UploadCollection").getModel().setData({
				"items": aItems
			});
			this.byId("attachmentTitle").setText(this.getAttachmentTitleText());
		},
		
		// 	onChange: function(oEvent) {
		// 	var oUploadCollection = oEvent.getSource();
		// 	// Header Token
		// 	var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
		// 		name: "x-csrf-token",
		// 		value: "securityTokenFromModel"
		// 	});
		// 	oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
		// },

onBeforeUpload: function(oEvent) {
//	fileName1_details = oEvent ;
	return;
},

		
			onBeforeUploadStarts: function(oEvent) {
			
			
			var userdId= oEmpData.Pernr;
			var pageInd =this.getView().byId("empname333_preapprove").getValue();
			if(this.requestId === ""){
			 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
		
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"MOVPUR"+"|"+"NONFIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
		
		
		onBeforeUploadStarts1: function(oEvent) {
			var userdId= oEmpData.Pernr;
			var pageInd =this.getView().byId("empname333_preapprove").getValue();
		if(this.requestId === ""){
			 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"MOVPUR"+"|"+"FIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
		
			onBeforeUploadStarts2: function(oEvent) {
					var userdId= oEmpData.Pernr;
	var pageInd =this.getView().byId("empname333_preapprove").getValue();
	if(this.requestId === ""){
			 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
		
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"MOVSAL"+"|"+"NONFIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
	onBeforeUploadStarts3: function(oEvent) {
			var userdId= oEmpData.Pernr;
	var pageInd =this.getView().byId("empname333_preapprove").getValue();
		if(this.requestId === ""){
			 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"MOVSAL"+"|"+"FIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},
	onBeforeUploadStarts4: function(oEvent) {
		
			var userdId= oEmpData.Pernr;
	var pageInd =this.getView().byId("empname333_preapprove").getValue();
		if(this.requestId === ""){
				 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"IMMOVPUR"+"|"+"NONFIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

	onBeforeUploadStarts5: function(oEvent) {

	var userdId= oEmpData.Pernr;
		var pageInd =this.getView().byId("empname333_preapprove").getValue();
		if(this.requestId === ""){
			 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"IMMOVPUR"+"|"+"FIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

	onBeforeUploadStarts6: function(oEvent) {
		
			var userdId= oEmpData.Pernr;
	var pageInd =this.getView().byId("empname333_preapprove").getValue();
		if(this.requestId === ""){
				 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"IMMOVSAL"+"|"+"NONFIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},


	onBeforeUploadStarts7: function(oEvent) {
		
			var userdId= oEmpData.Pernr;
	var pageInd =this.getView().byId("empname333_preapprove").getValue();
		if(this.requestId === ""){
			 this.requestId = oEmpData.Pernr + dateFormat.format(new Date());
		
			}
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")+"|"+"IMMOVSAL"+"|"+"FIN|"+userdId+"|"+ this.requestId+"|"+pageInd
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);

			var oModel = this.getView().getModel();

			oModel.refreshSecurityToken();

			var oHeaders = oModel.oHeaders;

			var sToken = oHeaders['x-csrf-token'];

			var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({

				name: "x-csrf-token",

				value: sToken

			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);

		},

		onUploadComplete: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollectionPreAp");
			var oData = oUploadCollection.getModel().getData();
		
			this.attachmentFlagMovPur1 =true;
			
			if(oData !== null){
				oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "MOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "MOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			
			oUploadCollection.getModel().refresh();
		},
		
			onUploadComplete1: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection13");
			var oData = oUploadCollection.getModel().getData();
			
				this.attachmentFlagMovPur2 =true;
		

		if(oData !== null){
				oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "FIN", 
				"TabInd": "MOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "FIN", 
				"TabInd": "MOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			oUploadCollection.getModel().refresh();
		},
			onUploadComplete2: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection23");
			var oData = oUploadCollection.getModel().getData();

			this.attachmentFlagMovSal1 =true;
		
			if(oData !== null){
				oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "MOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
				
			}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "MOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			
			oUploadCollection.getModel().refresh();
		},
			onUploadComplete3: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection33");
			var oData = oUploadCollection.getModel().getData();
				this.attachmentFlagMovSal2 =true;
		
	if(oData !== null){
			oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "FIN", 
				"TabInd": "MOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
	}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "FIN", 
				"TabInd": "MOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			oUploadCollection.getModel().refresh();
		},
			onUploadComplete4: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection43");
			var oData = oUploadCollection.getModel().getData();
			this.attachmentFlagImmovPur1 =true;
		
			if(oData !== null){	oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "IMMOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "IMMOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			oUploadCollection.getModel().refresh();
		},
			onUploadComplete5: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection53");
			var oData = oUploadCollection.getModel().getData();
	this.attachmentFlagImmovPur2 =true;
		
			if(oData !== null){	oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "FIN", 
				"TabInd": "IMMOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
			"Indicator": "FIN", 
				"TabInd": "IMMOVPUR",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			oUploadCollection.getModel().refresh();
		},
			onUploadComplete6: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection63");
			var oData = oUploadCollection.getModel().getData();
				this.attachmentFlagImmovSal1 =true;
		

				if(oData !== null){
					oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "IMMOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
				}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "NONFIN", 
				"TabInd": "IMMOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			oUploadCollection.getModel().refresh();
		},
			onUploadComplete7: function(oEvent) {
			var oUploadCollection = this.byId("UploadCollection73");
			var oData = oUploadCollection.getModel().getData();
			this.attachmentFlagImmovSal2 =true;
		
				if(oData !== null){
					oData.results.unshift({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "FIN", 
				"TabInd": "IMMOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
				}else{
				oData=[];
				oData.results=[];
				oData.results.push({
				"FileName": oEvent.getParameter("files")[0].fileName,
				"Indicator": "FIN", 
				"TabInd": "IMMOVSAL",
				"UserId": "",
				"RequestId": "",
					"PageIndicator":"Preapprove"
			});
			}
			oUploadCollection.getModel().refresh();
		}

	});

});